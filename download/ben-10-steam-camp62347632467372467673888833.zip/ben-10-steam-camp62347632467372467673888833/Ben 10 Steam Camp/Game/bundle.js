! function(f) {
    if ("object" == typeof exports && "undefined" != typeof module) module.exports = f();
    else if ("function" == typeof define && define.amd) define([], f);
    else {
        var g;
        g = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this, g.p3lib = f()
    }
}(function() {
    return function e(t, n, r) {
        function s(o, u) {
            if (!n[o]) {
                if (!t[o]) {
                    var a = "function" == typeof require && require;
                    if (!u && a) return a(o, !0);
                    if (i) return i(o, !0);
                    var f = new Error("Cannot find module '" + o + "'");
                    throw f.code = "MODULE_NOT_FOUND", f
                }
                var l = n[o] = {
                    exports: {}
                };
                t[o][0].call(l.exports, function(e) {
                    var n = t[o][1][e];
                    return s(n ? n : e)
                }, l, l.exports, e, t, n, r)
            }
            return n[o].exports
        }
        for (var i = "function" == typeof require && require, o = 0; o < r.length; o++) s(r[o]);
        return s
    }({
        1: [function(require, module, exports) {
            "use strict";

            function Actor(sequence, defaultAnimation) {
                this.view = null, this.signals = {}, this.destroyNextFrame = !1, this.bodyOffset = new PIXI.Point, this._health = 100, this._currentHealth = this._health, this._material = new p2.Material, this._body = this.createBody(), this._body.parent = this, this._body.updateMassProperties(), Common.world.addBody(this._body), PIXI.Container.call(this), this.anchor = new PIXI.Point(.5, .5), this.on("added", this.init, this)
            }
            var Common = require("./Common");
            module.exports = Actor, Actor.prototype = Object.create(PIXI.Container.prototype), Actor.prototype.constructor = Actor, Actor.prototype.createBody = function() {
                throw new Error("Must return a physics body!")
            }, Actor.prototype.init = function() {
                this._body.position = [this.x - this.bodyOffset.x, this.y - this.bodyOffset.y], this._body.angle = this.rotation
            }, Actor.prototype.destroy = function() {
                this._body && Common.world.removeBody(this._body), PIXI.Container.prototype.destroy.call(this)
            }, Actor.prototype.update = function() {
                this.syncToBody()
            }, Actor.prototype.syncToBody = function() {
                this.x = this._body.position[0] - this.bodyOffset.x, this.y = this._body.position[1] - this.bodyOffset.y, this.rotation = this._body.angle
            }, Actor.prototype.heal = function(value) {
                value = Math.abs(value), this._currentHealth += value, this._currentHealth = Math.min(this._health, this._currentHealth)
            }, Actor.prototype.takeDamage = function(value, source, animate) {
                return value = Math.abs(value), this._currentHealth -= value, this._currentHealth < 0 && this.signals.dead.dispatch(this), this.dead
            }, Actor.prototype.debugDraw = function(graphics) {}, Object.defineProperty(Actor.prototype, "spine", {
                get: function() {
                    return this.view
                },
                set: function(value) {
                    this.view = value
                }
            }), Object.defineProperty(Actor.prototype, "body", {
                get: function() {
                    return this._body
                }
            }), Object.defineProperty(Actor.prototype, "health", {
                get: function() {
                    return this._currentHealth
                },
                set: function(value) {
                    this._currentHealth = value, this._health = this._currentHealth
                }
            }), Object.defineProperty(Actor.prototype, "material", {
                get: function() {
                    return this._material
                }
            }), Object.defineProperty(Actor.prototype, "dead", {
                get: function() {
                    return this._currentHealth <= 0
                }
            })
        }, {
            "./Common": 10
        }],
        2: [function(require, module, exports) {
            "use strict";

            function Application() {}
            var Common = (require("./AudioParams"), require("./Common")),
                ConfirmScene = require("./ConfirmScene"),
                GameScene = require("./GameScene"),
                HelpScene = require("./HelpScene"),
                IntroScene = require("./IntroScene"),
                ResultScene = require("./ResultScene"),
                SplashScene = require("./SplashScene");
            module.exports = Application, Application.prototype.init = function() {
                this.showSplashScene()
            }, Application.prototype.showSplashScene = function() {
                Common.level = 0, Common.currentScore = 0;
                var scene = new SplashScene;
                scene.signals.next.add(function() {
                    this.showIntroScene()
                }, this);
                var transition = new p3.FadeTransition(0, 1);
                return Common.scene.add(scene, transition), scene
            }, Application.prototype.showIntroScene = function() {
                var scene = new IntroScene;
                scene.signals.next.add(function() {
                    this.showGameScene()
                }, this), scene.signals.home.add(function() {
                    this.showSplashScene()
                }, this);
                var transition = new p3.FadeTransition(0, 1);
                return Common.scene.add(scene, transition), scene
            }, Application.prototype.showGameScene = function() {
                Common.animator.paused = !1;
                var scene = new GameScene;
                scene.signals.next.add(function(score, victory) {
                    !victory || Common.level >= Common.config.levels.length - 1 ? (Common.currentScore = 0, Common.saveHighscore(score), this.showResultScene(score, victory)) : (++Common.level, this.showGameScene())
                }, this), scene.signals.pause.add(function(scene, paused) {
                    Common.animator.paused = !0;
                    var help = this.showHelpScene(paused);
                    help.signals.next.add(function() {
                        Common.animator.paused = !1
                    }, this, 1)
                }, this);
                var transition = new p3.FadeTransition(0, 1);
                return Common.scene.add(scene, transition), scene
            }, Application.prototype.showHelpScene = function(paused) {
                var scene = new HelpScene(paused);
                scene.signals.home.add(function() {
                    var confirm = this.showConfirmScene();
                    confirm.signals.next.add(function() {
                        this.showSplashScene()
                    }, this, 1), confirm.signals.previous.add(function() {
                        scene.signals.next.dispatch(this)
                    }, this, 1)
                }, this), scene.signals.next.add(function() {
                    Common.scene.remove()
                }, this);
                var transition = new p3.Transition;
                return transition.push = !0, Common.scene.add(scene, transition), scene
            }, Application.prototype.showResultScene = function(score, victory) {
                var scene = new ResultScene(score, victory);
                scene.signals.previous.add(function() {
                    this.showGameScene()
                }, this), scene.signals.next.add(function() {
                    this.showSplashScene()
                }, this), scene.signals.home.add(function() {
                    this.showSplashScene()
                }, this);
                var transition = new p3.FadeTransition(0, 1);
                return Common.scene.add(scene, transition), scene
            }, Application.prototype.showConfirmScene = function() {
                var scene = new ConfirmScene;
                scene.signals.previous.add(function() {
                    Common.scene.remove()
                }, this);
                var transition = new p3.Transition;
                return transition.push = !0, transition.replace = !1, Common.scene.add(scene, transition), scene
            }
        }, {
            "./AudioParams": 4,
            "./Common": 10,
            "./ConfirmScene": 11,
            "./GameScene": 15,
            "./HelpScene": 18,
            "./IntroScene": 22,
            "./ResultScene": 32,
            "./SplashScene": 34
        }],
        3: [function(require, module, exports) {
            function AudioManager() {
                this._cache = {}, this._music = null, this._isMuted = !1;
                var hidden;
                "undefined" != typeof document.hidden ? (hidden = "hidden", this.visibilityChange = "visibilitychange") : "undefined" != typeof document.mozHidden ? (hidden = "mozHidden", this.visibilityChange = "mozvisibilitychange") : "undefined" != typeof document.msHidden ? (hidden = "msHidden", this.visibilityChange = "msvisibilitychange") : "undefined" != typeof document.webkitHidden && (hidden = "webkitHidden", this.visibilityChange = "webkitvisibilitychange"), document.addEventListener(this.visibilityChange, function() {
                    document[hidden] ? Howler.volume(0) : Howler.volume(1)
                }, !1)
            }
            var AudioParams = require("./AudioParams");
            module.exports = AudioManager, AudioManager.prototype.addSounds = function(sounds, extensions, basePath) {
                basePath = basePath || "";
                var howl, name, url, urls, extension, i, j;
                for (i = 0; i < sounds.length; ++i) {
                    for (url = basePath + sounds[i], url = url.split("/"), name = url[url.length - 1], urls = [], j = 0; j < extensions.length; ++j) extension = extensions[j], urls.push(url.join("/") + extension);
                    howl = new Howl({
                        src: urls,
                        volume: 1,
                        loop: !1,
                        autoplay: !1,
                        onloaderror: function() {
                            console.warn("Error loading sound - " + name)
                        }
                    }), howl.name = name, this._cache[name] = howl
                }
            }, AudioManager.prototype.removeSounds = function(sounds) {
                for (var name, n, howl, i = 0; i < sounds.length; ++i) {
                    name = sounds[i];
                    for (n in this._cache)
                        if (this._cache.hasOwnProperty(key) && (howl = this._cache[key], howl.name == n)) {
                            howl.unload(), delete this._cache[name];
                            break
                        }
                }
            }, AudioManager.prototype.playSound = function(name, params) {
                params = params || new AudioParams, "string" != typeof name && (name = name[Math.floor(Math.random() * name.length)]);
                var howl = this._cache[name];
                return howl ? (howl.volume(params.volume), howl.loop(params.loop), p3.Device && p3.Device.isAndroidStockBrowser && (howl.buffer = !0), params.fadeIn > 0 ? this.fadeIn(howl, params.fadeIn) : howl.play(), howl) : (console.warn("Could not find sound - " + name), null)
            }, AudioManager.prototype.playMusic = function(name, params) {
                if (params = params || new AudioParams, "string" != typeof name && (name = name[Math.floor(Math.random() * name.length)]), this._music && this._music.name == name) return this._music;
                var howl = this._cache[name];
                return howl ? (howl.volume(params.volume), howl.loop(!0), howl.__onend = function() {
                    params.callback && params.callback.call(params.scope)
                }, howl.on("end", howl.__onend), p3.Device && p3.Device.isAndroidStockBrowser && (howl.buffer = !0), params.fadeIn > 0 ? (this._music && this._music.name != name && this.fadeOut(this._music, params.fadeIn, function(howl) {
                    howl.stop()
                }, this), this.fadeIn(howl, params.fadeIn)) : (this._music && this.stopMusic(), howl.play()), this._music = howl, howl) : (console.warn("Could not find music - " + name), null)
            }, AudioManager.prototype.stopSound = function(name) {
                var howl;
                for (var n in this._cache)
                    if (this._cache.hasOwnProperty(n) && (howl = this._cache[n], howl.name == name)) {
                        howl.stop();
                        break
                    }
            }, AudioManager.prototype.stopMusic = function(name) {
                name = name || this._music.name, this._music && this._music.name == name && (this._music.__onend && this._music.off("end", this._music.__onend), this._music.stop(), this._music = null)
            }, AudioManager.prototype.mute = function(value) {
                this._isMuted = value, this._isMuted ? Howler.mute(!0) : Howler.mute(!1)
            }, AudioManager.prototype.fadeIn = function(howl, duration, callback, scope) {
                duration = duration || 1, howl.volume(0), howl.play(), howl.__volume = howl._volume, TweenMax.killTweensOf(howl), TweenMax.to(howl, duration, {
                    __volume: 1,
                    ease: Power1.easeInOut,
                    onUpdate: function() {
                        howl.volume(howl.__volume)
                    },
                    onUpdateScope: this,
                    onComplete: callback,
                    onCompleteParams: [howl],
                    onCompleteScope: scope
                })
            }, AudioManager.prototype.fadeOut = function(howl, duration, callback, scope) {
                duration = duration || 1, howl.__volume = howl._volume, TweenMax.killTweensOf(howl), TweenMax.to(howl, duration, {
                    __volume: 0,
                    ease: Power1.easeInOut,
                    onUpdate: function() {
                        howl.volume(howl.__volume)
                    },
                    onUpdateScope: this,
                    onComplete: callback,
                    onCompleteParams: [howl],
                    onCompleteScope: scope
                })
            }, Object.defineProperty(AudioManager.prototype, "isMute", {
                get: function() {
                    return this._isMuted
                }
            })
        }, {
            "./AudioParams": 4
        }],
        4: [function(require, module, exports) {
            "use strict";

            function AudioParams() {
                this.volume = 1, this.loop = !1, this.delay = 0, this.fadeIn = 0, this.priority = 0, this.callback = null, this.scope = window
            }
            module.exports = AudioParams
        }, {}],
        5: [function(require, module, exports) {
            "use strict";

            function BenButton(states) {
                p3.Button.call(this, states), this._outerRing = new PIXI.Sprite(states.outerRing || PIXI.Texture.EMPTY), this._outerRing.anchor = new PIXI.Point(.5, .5), this.addChild(this._outerRing), this._innerRing = new PIXI.Sprite(states.innerRing || PIXI.Texture.EMPTY), this._innerRing.anchor = new PIXI.Point(.5, .5), this.addChild(this._innerRing)
            }
            module.exports = BenButton, BenButton.prototype = Object.create(p3.Button.prototype), BenButton.prototype.constructor = BenButton, BenButton.prototype.onMouseOver = function() {
                p3.Button.prototype.onMouseOver.call(this), TweenMax.killTweensOf(this._innerRing);
                var speed = 4;
                TweenMax.to(this._innerRing, (Math.PI - this._innerRing.rotation) / speed, {
                    rotation: Math.PI,
                    ease: Power1.easeInOut
                }), TweenMax.killTweensOf(this._outerRing), speed = 2, TweenMax.to(this._outerRing, Math.abs((-(.5 * Math.PI) - this._outerRing.rotation) / speed), {
                    rotation: .5 * -Math.PI,
                    ease: Power1.easeInOut
                })
            }, BenButton.prototype.onMouseOut = function() {
                p3.Button.prototype.onMouseOut.call(this), TweenMax.killTweensOf(this._innerRing);
                var speed = 4;
                TweenMax.to(this._innerRing, this._innerRing.rotation / speed, {
                    rotation: 0,
                    ease: Power1.easeInOut
                }), TweenMax.killTweensOf(this._outerRing), speed = 2, TweenMax.to(this._outerRing, Math.abs(this._outerRing.rotation / speed), {
                    rotation: 0,
                    ease: Power1.easeInOut
                })
            }
        }, {}],
        6: [function(require, module, exports) {
            "use strict";

            function BenMuteButton(states) {
                p3.MuteButton.call(this, states), this._outerRing = new PIXI.Sprite(states.outerRing || PIXI.Texture.EMPTY), this._outerRing.anchor = new PIXI.Point(.5, .5), this.addChild(this._outerRing), this._innerRing = new PIXI.Sprite(states.innerRing || PIXI.Texture.EMPTY), this._innerRing.anchor = new PIXI.Point(.5, .5), this.addChild(this._innerRing)
            }
            module.exports = BenMuteButton, BenMuteButton.prototype = Object.create(p3.MuteButton.prototype), BenMuteButton.prototype.constructor = BenMuteButton, BenMuteButton.prototype.onMouseOver = function() {
                p3.Button.prototype.onMouseOver.call(this), TweenMax.killTweensOf(this._innerRing);
                var speed = 4;
                TweenMax.to(this._innerRing, (Math.PI - this._innerRing.rotation) / speed, {
                    rotation: Math.PI,
                    ease: Power1.easeInOut
                }), TweenMax.killTweensOf(this._outerRing), speed = 2, TweenMax.to(this._outerRing, Math.abs((-(.5 * Math.PI) - this._outerRing.rotation) / speed), {
                    rotation: .5 * -Math.PI,
                    ease: Power1.easeInOut
                })
            }, BenMuteButton.prototype.onMouseOut = function() {
                p3.Button.prototype.onMouseOut.call(this), TweenMax.killTweensOf(this._innerRing);
                var speed = 4;
                TweenMax.to(this._innerRing, this._innerRing.rotation / speed, {
                    rotation: 0,
                    ease: Power1.easeInOut
                }), TweenMax.killTweensOf(this._outerRing), speed = 2, TweenMax.to(this._outerRing, Math.abs(this._outerRing.rotation / speed), {
                    rotation: 0,
                    ease: Power1.easeInOut
                })
            }
        }, {}],
        7: [function(require, module, exports) {
            "use strict";

            function CNPreloaderScene() {
                this.loaded = 0, this._bar = null, this._tweens = [], p3.Scene.call(this)
            }
            var Common = require("./Common");
            module.exports = CNPreloaderScene, CNPreloaderScene.prototype = Object.create(p3.Scene.prototype), CNPreloaderScene.prototype.constructor = CNPreloaderScene, CNPreloaderScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("cn_preloader_bg"));
                this.addChild(bg), this._bar = new PIXI.Container, this._bar.x = .5 * Common.STAGE_WIDTH + 4, this._bar.y = .5 * Common.STAGE_HEIGHT + 210, this.addChild(this._bar), this._bar.fill = new PIXI.Sprite(Common.assets.getTexture("cn_preloader_fill")), this._bar.fill.x = .5 * -this._bar.fill.texture.width, this._bar.fill.start = new PIXI.Point(this._bar.fill.x, this._bar.fill.y), this._bar.fill.anchor = new PIXI.Point(1, .5), this._bar.addChild(this._bar.fill), this._bar.frame = new PIXI.Sprite(Common.assets.getTexture("cn_preloader_overlay")), this._bar.frame.anchor = new PIXI.Point(.689, .5), this._bar.addChild(this._bar.frame)
            }, CNPreloaderScene.prototype.destroy = function() {
                for (var tween, i = 0; i < this._tweens.length; ++i) tween = this._tweens[i], tween.kill();
                this._tweens.length = 0, p3.Scene.prototype.destroy.call(this)
            }, CNPreloaderScene.prototype.show = function() {}, CNPreloaderScene.prototype.animateIn = function(callback, scope) {}, CNPreloaderScene.prototype.animateOut = function(callback, scope) {}, CNPreloaderScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH)
            }, CNPreloaderScene.prototype.update = function() {
                this._bar.fill.x = this._bar.fill.start.x + this.loaded * this._bar.fill.texture.width
            }
        }, {
            "./Common": 10
        }],
        8: [function(require, module, exports) {
            "use strict";

            function Camper() {
                this.speed = 108, this.direction = Math.random() < .5 ? -1 : 1, this._radius = 0, this._changeTime = 0, this._grounded = !1, this._scared = !1, this._mass = 1;
                var i, textures, sequence, type = Math.floor(8 * Math.random());
                switch (type) {
                    case 0:
                        for (this._mass = .62, this._radius = 46, textures = [], i = 0; i < 32; ++i) textures.push(Common.assets.getTexture("camper_woman_skirt_camper_001_idle_" + i));
                        for (sequence = new p3.MovieClipSequence, sequence.addTextures(textures), sequence.addTextures([Common.assets.getTexture("camper_woman_skirt_camper_001_hanging_0")], "chain"), textures = [], i = 0; i < 16; ++i) textures.push(Common.assets.getTexture("camper_woman_skirt_camper_001_run_" + i));
                        sequence.addTextures(textures, "run");
                        break;
                    case 1:
                        for (this._mass = .66, this._radius = 50, textures = [], i = 0; i < 32; ++i) textures.push(Common.assets.getTexture("camper_men_camper_002_idle_" + i));
                        for (sequence = new p3.MovieClipSequence, sequence.addTextures(textures), sequence.addTextures([Common.assets.getTexture("camper_men_camper_002_hanging_0")], "chain"), textures = [], i = 0; i < 16; ++i) textures.push(Common.assets.getTexture("camper_men_camper_002_run_" + i));
                        sequence.addTextures(textures, "run");
                        break;
                    case 2:
                        for (this._mass = .6, this._radius = 48, textures = [], i = 0; i < 32; ++i) textures.push(Common.assets.getTexture("camper_woman_camper_003_idle_" + i));
                        for (sequence = new p3.MovieClipSequence, sequence.addTextures(textures), sequence.addTextures([Common.assets.getTexture("camper_woman_camper_003_hanging_0")], "chain"), textures = [], i = 0; i < 16; ++i) textures.push(Common.assets.getTexture("camper_woman_camper_003_run_" + i));
                        sequence.addTextures(textures, "run");
                        break;
                    case 3:
                        for (this._mass = .64, this._radius = 52, textures = [], i = 0; i < 32; ++i) textures.push(Common.assets.getTexture("camper_woman_camper_004_idle_" + i));
                        for (sequence = new p3.MovieClipSequence, sequence.addTextures(textures), sequence.addTextures([Common.assets.getTexture("camper_woman_camper_004_hanging_0")], "chain"), textures = [], i = 0; i < 16; ++i) textures.push(Common.assets.getTexture("camper_woman_camper_004_run_" + i));
                        sequence.addTextures(textures, "run");
                        break;
                    case 4:
                        for (this._mass = .64, this._radius = 48, textures = [], i = 0; i < 32; ++i) textures.push(Common.assets.getTexture("camper_men_camper_005_idle_" + i));
                        for (sequence = new p3.MovieClipSequence, sequence.addTextures(textures), sequence.addTextures([Common.assets.getTexture("camper_men_camper_005_hanging_0")], "chain"), textures = [], i = 0; i < 16; ++i) textures.push(Common.assets.getTexture("camper_men_camper_005_run_" + i));
                        sequence.addTextures(textures, "run");
                        break;
                    case 5:
                        for (this._mass = .66, this._radius = 48, textures = [], i = 0; i < 32; ++i) textures.push(Common.assets.getTexture("camper_men_camper_006_idle_" + i));
                        for (sequence = new p3.MovieClipSequence, sequence.addTextures(textures), sequence.addTextures([Common.assets.getTexture("camper_men_camper_006_hanging_0")], "chain"), textures = [], i = 0; i < 16; ++i) textures.push(Common.assets.getTexture("camper_men_camper_006_run_" + i));
                        sequence.addTextures(textures, "run");
                        break;
                    case 6:
                        for (this._mass = .74, this._radius = 52, textures = [], i = 0; i < 32; ++i) textures.push(Common.assets.getTexture("camper_fat_camper_009_idle_" + i));
                        for (sequence = new p3.MovieClipSequence, sequence.addTextures(textures), sequence.addTextures([Common.assets.getTexture("camper_fat_camper_009_hanging_0")], "chain"), textures = [], i = 0; i < 16; ++i) textures.push(Common.assets.getTexture("camper_fat_camper_009_run_" + i));
                        sequence.addTextures(textures, "run");
                        break;
                    case 7:
                        for (this._mass = .74, this._radius = 52, textures = [], i = 0; i < 32; ++i) textures.push(Common.assets.getTexture("camper_fat_camper_010_idle_" + i));
                        for (sequence = new p3.MovieClipSequence, sequence.addTextures(textures), sequence.addTextures([Common.assets.getTexture("camper_fat_camper_010_hanging_0")], "chain"), textures = [], i = 0; i < 16; ++i) textures.push(Common.assets.getTexture("camper_fat_camper_010_run_" + i));
                        sequence.addTextures(textures, "run")
                }
                Actor.call(this), this.view = new p3.MovieClip(sequence), this.view.anchor = new PIXI.Point(.5, .5), this.view.looping = !0, this.addChild(this.view), this.chained = !1
            }
            var Actor = require("./Actor"),
                CollisionGroups = require("./CollisionGroups"),
                Common = require("./Common");
            module.exports = Camper, Camper.prototype = Object.create(Actor.prototype), Camper.prototype.constructor = Camper, Camper.prototype.createBody = function() {
                var body = new p2.Body({
                    mass: this._mass
                });
                body.type = p2.Body.DYNAMIC, body.allowSleep = !0, body.gravityScale = 1.6;
                var radius = this._radius,
                    shape = new p2.Circle({
                        radius: radius
                    });
                body.addShape(shape);
                var sensor = new p2.Circle({
                    radius: radius
                });
                return sensor.sensor = !0, sensor.collisionGroup = CollisionGroups.CAMPER, sensor.collisionMask = CollisionGroups.CAMPER, body.addShape(sensor), body
            }, Camper.prototype.update = function() {
                if (this._scared && !this.chained) {
                    var to = new PIXI.Point(this.speed * this.direction, 0);
                    this.move(to.x, to.y), this._changeTime <= 0 ? (this._changeTime = 1 + 4 * Math.random(), this.direction *= -1) : this._changeTime -= p3.Timestep.deltaTime
                }
                Actor.prototype.update.call(this)
            }, Camper.prototype.scare = function() {
                this._scared = !0, !this.chained && this.view.gotoAndPlay("run")
            }, Camper.prototype.move = function(x, y) {
                this.grounded && (this._body.applyForce([x, y]), this.scale.x = Math.abs(x) > 0 ? x / Math.abs(x) : this.scale.x, this.view.play())
            }, Camper.prototype.debugDraw = function(graphics) {
                var shape = this.body.shapes[0];
                graphics.lineStyle(2, 65280, .4), graphics.beginFill(65280, .2), graphics.drawCircle(this.body.position[0] + shape.position[0], this.body.position[1] + shape.position[1], shape.radius), graphics.endFill()
            }, Object.defineProperty(Camper.prototype, "chained", {
                get: function() {
                    return this._chained
                },
                set: function(value) {
                    this._chained = value;
                    var shape = this._body.shapes[0];
                    this._body.shapes[1];
                    value ? (this._body.fixedRotation = !1, shape.collisionGroup = CollisionGroups.CAMPER_CHAIN, shape.collisionMask = CollisionGroups.TERRAIN_FLOOR | CollisionGroups.TERRAIN_OTHER | CollisionGroups.SAFE_ZONE | CollisionGroups.PROJECTILE_BAD, this.view.gotoAndPlay("chain")) : (this._body.angle = 0, this._body.fixedRotation = !0, shape.collisionGroup = CollisionGroups.CAMPER, shape.collisionMask = CollisionGroups.TERRAIN_FLOOR | CollisionGroups.TERRAIN_OTHER | CollisionGroups.CAMPER_CHAIN | CollisionGroups.PLAYER, this.view.gotoAndPlay(this.scared ? "run" : "default"))
                }
            }), Object.defineProperty(Camper.prototype, "grounded", {
                get: function() {
                    return this._grounded
                },
                set: function(value) {
                    this._grounded = value, this._body.damping = value ? .82 : 0
                }
            }), Object.defineProperty(Camper.prototype, "scared", {
                get: function() {
                    return this._scared
                }
            })
        }, {
            "./Actor": 1,
            "./CollisionGroups": 9,
            "./Common": 10
        }],
        9: [function(require, module, exports) {
            "use strict";

            function CollisionGroups() {}
            module.exports = CollisionGroups, CollisionGroups.PLAYER = 2, CollisionGroups.CAMPER = 4, CollisionGroups.ENEMY = 8, CollisionGroups.CAMPER_CHAIN = 16, CollisionGroups.PROJECTILE_GOOD = 32, CollisionGroups.PROJECTILE_BAD = 64, CollisionGroups.SAFE_ZONE = 128, CollisionGroups.TERRAIN_FLOOR = 256, CollisionGroups.TERRAIN_OTHER = 512, CollisionGroups.JUNK = 1024, CollisionGroups.POWERUP = 2048, CollisionGroups.GIESER = 4096
        }, {}],
        10: [function(require, module, exports) {
            "use strict";

            function Common() {}
            module.exports = Common, Common.STAGE_WIDTH = 1900, Common.STAGE_HEIGHT = 768, Common.stage = null, Common.renderer = null, Common.timestep = null, Common.tracking = null, Common.animator = null, Common.sceneManager = null, Common.assetManager = null, Common.audio = null, Common.camera = null, Common.player = null, Common.copy = null, Common.config = null, Common.language = "en", Common.touch = new PIXI.Point(0, 0), Common.touching = !1, Common.paused = !1, Common.isWebGL = !1, Common.level = 0, Common.levelWidth = 0, Common.currentScore = 0, Common.isFirstPlay = !0, Common.saveHighscore = function(value) {
                var score = parseInt(window.localStorage.getItem("cnscscore")) || 0;
                value > score && (window.localStorage.cnscscore = value)
            }, Common.getHighscore = function() {
                return window.localStorage.getItem("cnscscore") || 0
            }, Common.inViewport = function(a, padding) {
                padding = padding || 0;
                var camera = Common.camera;
                return a.x > camera.position.x + camera.view.x - .5 * p3.View.width - padding && a.x < camera.position.x + camera.view.x + .5 * p3.View.width + padding
            }
        }, {}],
        11: [function(require, module, exports) {
            "use strict";

            function ConfirmScene() {
                this._overlay = null, this._panel = null, this._titleText = null, this._yesButton = null, this._noButton = null, p3.Scene.call(this)
            }
            var BenButton = require("./BenButton"),
                Common = (require("./BenMuteButton"), require("./Common"));
            module.exports = ConfirmScene, ConfirmScene.prototype = Object.create(p3.Scene.prototype), ConfirmScene.prototype.constructor = ConfirmScene, ConfirmScene.prototype.init = function() {
                this._overlay = new PIXI.Graphics, this.addChild(this._overlay), this._panel = new PIXI.Sprite(Common.assets.getTexture("pop_up_are_you_sure")), this._panel.x = .5 * Common.STAGE_WIDTH, this._panel.y = .5 * Common.STAGE_HEIGHT, this._panel.anchor = new PIXI.Point(.5, .5), this.addChild(this._panel), "ar" != Common.language && "ru" != Common.language ? (this._titleText = new PIXI.extras.BitmapText(Common.copy.areyousure[Common.language], {
                    font: "64px Ahkio Green",
                    align: "center"
                }), this._titleText.x = .5 * -this._titleText.textWidth, this._titleText.y = -100, this._panel.addChild(this._titleText)) : (this._titleText = new PIXI.Text(Common.copy.areyousure[Common.language], {
                    font: "64px Arial",
                    fill: "#69FF00",
                    stroke: "#044300",
                    strokeThickness: 10,
                    align: "center"
                }), this._titleText.x = .5 * -this._titleText.width, this._titleText.y = -100, this._panel.addChild(this._titleText));
                var states = new p3.ButtonStates;
                states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_tick_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_tick_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._yesButton = new BenButton(states), this._yesButton.x = 114, this._yesButton.y = 68, this._yesButton.animate = !0, this._yesButton.overSoundName = "sfx_btn_rollover_00", this._yesButton.clickSoundName = "sfx_btn_play_00", this._yesButton.signals.click.add(this.onYesButtonClick, this), this._panel.addChild(this._yesButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_close_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_close_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._noButton = new BenButton(states), this._noButton.x = -114, this._noButton.y = 68, this._noButton.animate = !0, this._noButton.overSoundName = "sfx_btn_rollover_00", this._noButton.clickSoundName = "sfx_btn_back", this._noButton.signals.click.add(this.onNoButtonClick, this), this._panel.addChild(this._noButton), p3.Scene.prototype.init.call(this)
            }, ConfirmScene.prototype.destroy = function() {
                this._yesButton.destroy(), this._noButton.destroy(), p3.Scene.prototype.destroy.call(this)
            }, ConfirmScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._overlay.beginFill(0, .6), this._overlay.drawRect(.5 * (Common.STAGE_WIDTH - p3.View.width), 0, p3.View.width, p3.View.height), this._overlay.endFill()
            }, ConfirmScene.prototype.update = function() {}, ConfirmScene.prototype.onYesButtonClick = function(button) {
                this.signals.next.dispatch(this)
            }, ConfirmScene.prototype.onNoButtonClick = function(button) {
                this.signals.previous.dispatch(this)
            }
        }, {
            "./BenButton": 5,
            "./BenMuteButton": 6,
            "./Common": 10
        }],
        12: [function(require, module, exports) {
            "use strict";

            function DistortionEffect() {}
            module.exports = DistortionEffect, DistortionEffect.shake = function(display) {
                function animate() {
                    TweenMax.killTweensOf(filter);
                    var delay = 2 + 6 * Math.random(),
                        tl = new TimelineMax({
                            delay: delay,
                            onComplete: animate,
                            onUpdate: function() {
                                filter.time += 1
                            }
                        });
                    tl.append(TweenMax.to(filter, .2, {
                        amplitude: .14,
                        frequency: 2.4,
                        ease: Power1.easeIn,
                        yoyo: !0,
                        repeat: 1
                    })), Math.random() < .4 && (tl.append(TweenMax.to(filter, .24, {
                        amplitude: .18,
                        frequency: 2,
                        ease: Power1.easeIn,
                        yoyo: !0,
                        repeat: 1
                    })), TweenMax.to(display, .2, {
                        delay: delay,
                        alpha: .7,
                        ease: Power1.easeInOut,
                        yoyo: !0,
                        repeat: 1
                    }))
                }
                var filter = new p3.DistortionFilter(0, 0);
                animate(), display.filters ? display.filters.unshift(filter) : display.filters = [filter]
            }
        }, {}],
        13: [function(require, module, exports) {
            "use strict";

            function Enemy() {
                this.speed = 108, this.attackDistance = 0, this.target = null, this.campers = [], this.grounded = !1, this._moving = !1, Actor.call(this), this.signals.dead = new signals.Signal
            }
            var Actor = require("./Actor"),
                Common = (require("./CollisionGroups"), require("./Common"));
            module.exports = Enemy, Enemy.prototype = Object.create(Actor.prototype), Enemy.prototype.constructor = Enemy, Enemy.prototype.destroy = function() {
                this.signals.dead.dispose(), Actor.prototype.destroy.call(this)
            }, Enemy.prototype.createBody = function() {
                var body = new p2.Body({
                    mass: .62
                });
                return body.type = p2.Body.DYNAMIC, body
            }, Enemy.prototype.move = function(x, y) {
                this.grounded && (this._body.applyForce([x, y]), this.scale.x = Math.abs(x) > 0 ? x / Math.abs(x) : this.scale.x, this._moving || (this.spine.state.setAnimationByName(0, "walk", !0), Common.inViewport(this) && Common.audio.playSound("sfx_robot_start_00")), this._moving = !0)
            }, Enemy.prototype.stop = function() {
                this._moving && (this._moving = !1, this.spine.state.setAnimationByName(0, "idle", !0), Common.inViewport(this, 240) && Common.audio.playSound("sfx_robot_stop_00"))
            }, Enemy.prototype.takeDamage = function(damage, source, animate) {
                var sounds = ["sfx_stinkfly_gasattack_00", "sfx_stinkfly_gasattack_01", "sfx_stinkfly_gloophit_00"];
                return Common.audio.playSound(sounds), this.dead && this.playExplosionEffect(), Actor.prototype.takeDamage.call(this, damage, source, animate)
            }, Enemy.prototype.playExplosionEffect = function() {
                var config, emitter;
                config = Common.assets.getJSON("particle_emitter_robot_explode_00"), emitter = new cloudkid.Emitter(this.parent, [Common.assets.getTexture("particle_robot_001"), Common.assets.getTexture("particle_robot_002"), Common.assets.getTexture("particle_robot_003"), Common.assets.getTexture("particle_robot_004"), Common.assets.getTexture("particle_robot_005"), Common.assets.getTexture("particle_robot_006"), Common.assets.getTexture("particle_robot_007"), Common.assets.getTexture("particle_robot_008")], config), emitter.emit = !0, emitter.updateOwnerPos(this.x, this.y), Common.animator.add(emitter), config = Common.assets.getJSON("particle_emitter_explosion_big_smoke_00"), emitter = new cloudkid.Emitter(this.parent, [Common.assets.getTexture("particle_smoke_001"), Common.assets.getTexture("particle_smoke_002"), Common.assets.getTexture("particle_smoke_003"), Common.assets.getTexture("particle_smoke_004")], config), emitter.emit = !0, emitter.updateOwnerPos(this.x, this.y), Common.animator.add(emitter)
            }, Enemy.prototype.randomizeDirection = function() {
                this.x < .5 * -Common.levelWidth + 420 ? this.direction = 1 : this.x > .5 * Common.levelWidth - 420 ? this.direction = -1 : this.direction = Math.random() < .5 ? 1 : -1
            }, Enemy.prototype.debugDraw = function(graphics) {}
        }, {
            "./Actor": 1,
            "./CollisionGroups": 9,
            "./Common": 10
        }],
        14: [function(require, module, exports) {
            "use strict";

            function FlyBot() {
                Enemy.call(this), this.speed = 200, this.direction = 1;
                var holder = new PIXI.Container;
                holder.y = 26, this.addChild(holder), this.spine = new PIXI.spine.Spine(Common.assets.getSpineData("char_robot_003")), this.spine.skeleton.setToSetupPose(), this.spine.skeleton.setSkin(null), this.spine.autoUpdate = !1, this.spine.scale.set(.5), holder.addChild(this.spine), this.bodyOffset = new PIXI.Point(0, 18), this.signals.dead = new signals.Signal
            }
            var CollisionGroups = (require("./Actor"), require("./CollisionGroups")),
                Common = require("./Common"),
                Enemy = require("./Enemy");
            module.exports = FlyBot, FlyBot.prototype = Object.create(Enemy.prototype), FlyBot.prototype.constructor = FlyBot, FlyBot.prototype.init = function() {
                Enemy.prototype.init.call(this);
                var to = new p3.Vector2(this.target.x - this.x, this.target.y - this.y);
                this.direction = to.x / Math.abs(to.x), this.spine.state.setAnimationByName(0, "idle", !0)
            }, FlyBot.prototype.createBody = function() {
                var body = new p2.Body({
                    mass: .62
                });
                body.type = p2.Body.DYNAMIC, body.allowSleep = !0, body.damping = .82, body.gravityScale = 0, body.fixedRotation = !0;
                var radius = 32,
                    shape = new p2.Circle({
                        radius: radius
                    });
                shape.collisionGroup = CollisionGroups.ENEMY, shape.collisionMask = CollisionGroups.TERRAIN_FLOOR, body.addShape(shape);
                var sensor = new p2.Circle({
                    radius: radius
                });
                return sensor.collisionGroup = CollisionGroups.ENEMY, sensor.collisionMask = CollisionGroups.PLAYER | CollisionGroups.PROJECTILE_GOOD, sensor.sensor = !0, body.addShape(sensor), body
            }, FlyBot.prototype.update = function() {
                Enemy.prototype.update.call(this), this.move(this.speed * this.direction, 0);
                var remove = !1,
                    camera = Common.camera;
                1 == this.direction ? this.x > camera.position.x + camera.view.x + .5 * p3.View.width + 140 && (remove = !0) : this.direction == -1 && this.x < camera.position.x + camera.view.x - .5 * p3.View.width - 140 && (remove = !0), remove && this.signals.dead.dispatch(this, !0)
            }, FlyBot.prototype.move = function(x, y) {
                this._body.applyForce([x, y]), this.scale.x = Math.abs(x) > 0 ? x / Math.abs(x) : this.scale.x
            }, FlyBot.prototype.playExplosionEffect = function() {
                var config, emitter;
                config = Common.assets.getJSON("particle_emitter_robot_explode_00"), emitter = new cloudkid.Emitter(this.parent, [Common.assets.getTexture("particle_robot_001"), Common.assets.getTexture("particle_robot_002"), Common.assets.getTexture("particle_robot_003"), Common.assets.getTexture("particle_robot_004"), Common.assets.getTexture("particle_robot_005"), Common.assets.getTexture("particle_robot_006"), Common.assets.getTexture("particle_robot_007"), Common.assets.getTexture("particle_robot_008")], config), emitter.emit = !0, emitter.updateOwnerPos(this.x, this.y), Common.animator.add(emitter), config = Common.assets.getJSON("particle_emitter_explosion_smoke_00"), emitter = new cloudkid.Emitter(this.parent, [Common.assets.getTexture("particle_smoke_001"), Common.assets.getTexture("particle_smoke_002"), Common.assets.getTexture("particle_smoke_003"), Common.assets.getTexture("particle_smoke_004")], config), emitter.emit = !0, emitter.updateOwnerPos(this.x, this.y),
                    Common.animator.add(emitter), Common.audio.playSound("sfx_robot_steam_explode_00")
            }, FlyBot.prototype.debugDraw = function(graphics) {
                var shape = this.body.shapes[0];
                graphics.lineStyle(2, 255, .4), graphics.beginFill(255, .2), graphics.drawCircle(this.body.position[0] + shape.position[0], this.body.position[1] + shape.position[1], shape.radius), graphics.endFill()
            }
        }, {
            "./Actor": 1,
            "./CollisionGroups": 9,
            "./Common": 10,
            "./Enemy": 13
        }],
        15: [function(require, module, exports) {
            "use strict";

            function GameScene() {
                p3.Scene.call(this), this._background = null, this._midground = null, this._foreground = null, this._game = null, this._debug = null, this._player = null, this._terrain = null, this._van = null, this._safeZone = null, this._tents = [], this._campers = [], this._enemies = [], this._projectiles = [], this._powerups = [], this._junk = [], this._geysers = [], this._score = Common.currentScore, this._campersSaved = 0, this._campersTotal = 0, this._enemiesKilled = 0, this._multiplier = 1, this._multiplierTimer = null, this._hud = null, this._running = !1, this._isNight = !1
            }
            var AudioParams = (require("./Actor"), require("./AudioParams")),
                Camper = require("./Camper"),
                CollisionGroups = require("./CollisionGroups"),
                Common = require("./Common"),
                Enemy = require("./Enemy"),
                FlyBot = require("./FlyBot"),
                Geyser = require("./Geyser"),
                GroundBot = require("./GroundBot"),
                HoverBot = require("./HoverBot"),
                Hud = require("./Hud"),
                Junk = require("./Junk"),
                Player = require("./Player"),
                Powerup = require("./Powerup"),
                PowerupTypes = require("./PowerupTypes"),
                PreloaderScene = require("./PreloaderScene"),
                Projectile = require("./Projectile"),
                SafeZone = require("./SafeZone"),
                Tent = require("./Tent");
            module.exports = GameScene, GameScene.prototype = Object.create(p3.Scene.prototype), GameScene.prototype.constructor = GameScene, GameScene.prototype.preloader = function() {
                return new PreloaderScene
            }, GameScene.prototype.load = function() {
                return [{
                    name: "game_0",
                    url: "images/game_0.json"
                }, {
                    name: "game_robot_0",
                    url: "images/game_robot_0.json"
                }, {
                    name: "game_campers_0",
                    url: "images/game_campers_0.json"
                }, {
                    name: "game_tiles_0",
                    url: "images/game_tiles_0.json"
                }, {
                    name: "bg_game_day",
                    url: "images/bg_game_day.jpg"
                }, {
                    name: "bg_game_night",
                    url: "images/bg_game_night.jpg"
                }, {
                    name: "char_stinkfly",
                    url: "images/char_stinkfly.json"
                }, {
                    name: "char_robot",
                    url: "images/char_robot.json"
                }, {
                    name: "char_robot_002",
                    url: "images/char_robot_002.json"
                }, {
                    name: "char_robot_003",
                    url: "images/char_robot_003.json"
                }]
            }, GameScene.prototype.unload = function() {
                Common.assets
            }, GameScene.prototype.init = function() {
                this._isNight = Common.level % 2;
                var bg = new PIXI.Sprite(Common.assets.getTexture(this._isNight ? "bg_game_night" : "bg_game_day"));
                this.addChild(bg), this._background = new PIXI.Container, this.addChild(this._background), this._midground = new PIXI.Container, this.addChild(this._midground), this._game = new PIXI.Container, this.addChild(this._game), this._debug = new PIXI.Graphics, this.addChild(this._debug), this._foreground = new PIXI.Container, this.addChild(this._foreground);
                var camera = new p3.Camera(new PIXI.Point(.5 * Common.STAGE_WIDTH, 320));
                camera.addLayer("background", this._background, new PIXI.Point(.4, 1)), camera.addLayer("midground", this._midground, new PIXI.Point(.6, 1)), camera.addLayer("game", this._game, new PIXI.Point(1, 1)), camera.addLayer("debug", this._debug, new PIXI.Point(1, 1)), camera.addLayer("foreground", this._foreground, new PIXI.Point(1.4, 1)), Common.camera = camera, this.createWorld(), this.createTerrain(new PIXI.Point(0, Common.STAGE_HEIGHT - 40)), this._van = new PIXI.Sprite(Common.assets.getTexture(this._isNight ? "rustbucket_night" : "rustbucket_day")), this._van.anchor = new PIXI.Point(.5, .5), this._game.addChild(this._van), this._player = new Player, this._player.y = .5 * Common.STAGE_HEIGHT, this._player.signals.fire.add(this.onProjectileFire, this), this._player.signals.dead.add(this.onActorDead, this), this._game.addChild(this._player), Common.world.addContactMaterial(new p2.ContactMaterial(this._player.material, this._terrain.material1, {
                    restitution: .82,
                    stiffness: Number.MAX_VALUE
                })), Common.world.addContactMaterial(new p2.ContactMaterial(this._player.material, this._terrain.material2, {
                    restitution: .82,
                    stiffness: Number.MAX_VALUE
                })), this._safeZone = new SafeZone, this._safeZone.x = .5 * -Common.levelWidth + 200, this._safeZone.y = 584;
                var levelData = Common.config.levels[Common.level];
                this.spawnGeysers(levelData.geysers), this.spawnJunk(20 + 8 * Math.random()), this.spawnTents(levelData.tents), this.spawnEnemies(levelData.enemies.ground, levelData.enemies.fly, levelData.enemies.hover), this._game.addChild(this._safeZone), this._van.x = this._safeZone.x + 262, this._van.y = this._safeZone.y + 14, this._player.body.position[0] = this._van.x, this._player.update(), camera.trackTarget(this._player, !0), this._hud = new Hud, this._hud.signals.pause.add(this.onPauseButtonClick, this), this._hud.signals.fire.add(this.onFireButton, this), this._hud.signals.direction.add(this.onDirectionButtonClick, this), this._hud.joystick.signals.input.add(this.onJoystickInput, this), this.addChild(this._hud), this._multiplierTimer = new p3.Timer(2, 1), this._multiplierTimer.signals.timerComplete.add(this.onMultiplierTimerComplete, this), Common.animator.add(this._multiplierTimer), this.start()
            }, GameScene.prototype.destroy = function() {
                Common.animator.removeAll(), TweenMax.killAll(), this._player.destroy(), this._hud.destroy(), Common.world.clear(), p3.Scene.prototype.destroy.call(this)
            }, GameScene.prototype.start = function() {
                this._running = !0, this._hud.showLevelBanner(), Common.audio.playSound("sfx_omnitrix_transform_00")
            }, GameScene.prototype.end = function() {
                this._running = !1, this._player.dead && Common.audio.playSound("sfx_omnitrix_transform_back_00"), this.signals.next.dispatch(this._score, !this._player.dead)
            }, GameScene.prototype.createWorld = function() {
                var world = new p2.World({
                    gravity: [0, 120]
                });
                world.on("beginContact", this.onBeginContact, this), world.on("endContact", this.onEndContact, this), Common.world = world
            }, GameScene.prototype.createTerrain = function(position) {
                var tiles = 8;
                Common.levelWidth = 950 * tiles;
                var thickness = 40,
                    camera = Common.camera;
                camera.bounds.x = .5 * (-Common.levelWidth + p3.View.width), camera.bounds.width = .5 * (Common.levelWidth - p3.View.width), camera.bounds.y = camera.view.y, camera.bounds.height = camera.view.y, this._terrain = new p2.Body({
                    mass: 1
                }), this._terrain.type = p2.Body.STATIC, this._terrain.position = [position.x, position.y], this._terrain.allowSleep = !0, this._terrain.material1 = new p2.Material, this._terrain.material2 = new p2.Material;
                var floor = new p2.Box({
                    width: Common.levelWidth,
                    height: thickness
                });
                floor.material = this._terrain.material1, floor.collisionGroup = CollisionGroups.TERRAIN_FLOOR, floor.collisionMask = CollisionGroups.PLAYER | CollisionGroups.CAMPER | CollisionGroups.CAMPER_CHAIN | CollisionGroups.ENEMY | CollisionGroups.JUNK, this._terrain.addShape(floor);
                var top = new p2.Box({
                    width: Common.levelWidth,
                    height: thickness
                });
                top.material = this._terrain.material2, top.collisionGroup = CollisionGroups.TERRAIN_OTHER, top.collisionMask = CollisionGroups.PLAYER | CollisionGroups.CAMPER | CollisionGroups.CAMPER_CHAIN | CollisionGroups.ENEMY, this._terrain.addShape(top, [0, -position.y]);
                var left = new p2.Box({
                    width: thickness,
                    height: position.y
                });
                left.material = this._terrain.material2, left.collisionGroup = CollisionGroups.TERRAIN_OTHER, left.collisionMask = CollisionGroups.PLAYER | CollisionGroups.CAMPER | CollisionGroups.CAMPER_CHAIN | CollisionGroups.ENEMY, this._terrain.addShape(left, [.5 * -Common.levelWidth, .5 * -left.height]);
                var right = new p2.Box({
                    width: thickness,
                    height: position.y
                });
                right.material = this._terrain.material2, right.collisionGroup = CollisionGroups.TERRAIN_OTHER, right.collisionMask = CollisionGroups.PLAYER | CollisionGroups.CAMPER | CollisionGroups.CAMPER_CHAIN | CollisionGroups.ENEMY, this._terrain.addShape(right, [.5 * Common.levelWidth, .5 * -right.height]), Common.world.addBody(this._terrain);
                var tile, texture, textures, count, i;
                for (texture = this._isNight ? Common.assets.getTexture("tile_bg_night") : Common.assets.getTexture("tile_bg_day"), count = tiles - 2, i = 0; i < count; ++i) tile = new PIXI.Sprite(texture), tile.x = i * tile.width + 570 - texture.width * count * .5, tile.y = position.y - 400 + tile.height, tile.anchor.y = 1, this._background.addChildAt(tile, 0);
                for (textures = this._isNight ? [Common.assets.getTexture("tile_mg_night_001"), Common.assets.getTexture("tile_mg_night_002"), Common.assets.getTexture("tile_mg_night_003")] : [Common.assets.getTexture("tile_mg_day_001"), Common.assets.getTexture("tile_mg_day_002"), Common.assets.getTexture("tile_mg_day_003")], count = tiles, i = 0; i < count; ++i) tile = new PIXI.Sprite(textures[Math.floor(Math.random() * textures.length)]), tile.x = i * tile.width - texture.width * count * .5, tile.y = position.y - 360 + 260, tile.anchor.y = 1, this._midground.addChildAt(tile, 0);
                for (texture = Common.assets.getTexture("tile_path_001"), count = tiles, i = 0; i < count; ++i) tile = new PIXI.Sprite(texture), tile.x = i * tile.width - texture.width * count * .5, tile.y = position.y - 100 + tile.height, tile.anchor.y = 1, this._game.addChildAt(tile, 0);
                for (textures = [Common.assets.getTexture("tile_fg_001"), Common.assets.getTexture("tile_fg_002")], count = tiles + 4, i = 0; i < count; ++i) tile = new PIXI.Sprite(textures[Math.floor(Math.random() * textures.length)]), tile.x = i * tile.width - 190 - texture.width * count * .5, tile.y = position.y - 48 + tile.height, tile.anchor.y = 1, this._foreground.addChildAt(tile, 0)
            }, GameScene.prototype.spawnTents = function(array) {
                var tent, camper, count, i, j;
                for (i = 0; i < array.length; ++i) tent = new Tent, tent.x = this.findTentPosition().x, tent.y = 614, tent.scale.x = Math.random < .5 ? -1 : 1, this._game.addChild(tent), this._tents.push(tent);
                var spacing = 240;
                for (i = 0; i < array.length; ++i)
                    for (count = array[i], tent = this._tents[i], j = 0; j < count; ++j) camper = new Camper, camper.x = tent.x + Math.random() * (spacing - -spacing) - spacing, camper.y = 620, this._game.addChild(camper), this._campers.push(camper), ++this._campersTotal;
                this._player.parent.addChild(this._player)
            }, GameScene.prototype.spawnEnemies = function(ground, fly, hover) {
                var i;
                for (i = 0; i < ground; ++i) this.spawnBot(0);
                for (i = 0; i < fly; ++i) this.spawnBot(1);
                for (i = 0; i < hover; ++i) this.spawnBot(2)
            }, GameScene.prototype.spawnGeysers = function(count) {
                for (var gieser, i = 0; i < count; ++i) gieser = new Geyser, gieser.x = this.findTentPosition().x, gieser.y = 716, this._game.addChild(gieser), this._geysers.push(gieser)
            }, GameScene.prototype.spawnPowerup = function(type, position) {
                var powerup = new Powerup(type);
                powerup.x = position.x, powerup.y = position.y, this._game.addChild(powerup), this._powerups.push(powerup)
            }, GameScene.prototype.collectPowerup = function(powerup) {
                switch (powerup.destroyNextFrame = !0, powerup.type) {
                    case PowerupTypes.HEALTH:
                        this._player.heal(34);
                        break;
                    case PowerupTypes.INVULNERABILITY:
                        this._player.makeInvulnerable(10)
                }
                Common.audio.playSound("sfx_ben_orb")
            }, GameScene.prototype.spawnBot = function(type) {
                function posx() {
                    for (;;)
                        if (x = Math.random() * (halfw - -halfw) - halfw, !(x >= camera.position.x - padding && x <= camera.position.x + p3.View.width + padding) && x > this._safeZone.x + 600) return x
                }
                var x, bot, camera = Common.camera,
                    halfw = .5 * Common.levelWidth,
                    padding = 240;
                switch (type) {
                    case 0:
                        bot = new GroundBot, bot.x = posx.call(this), bot.y = 640, bot.health = 100, bot.giesers = this._geysers, bot.signals.attack.add(this.onBotAttack, this), bot.signals.fire.add(this.onProjectileFire, this);
                        break;
                    case 1:
                        bot = new FlyBot, bot.x = posx.call(this), bot.y = p3.Utils.randomRange(440, 140), bot.health = 20;
                        break;
                    case 2:
                        bot = new HoverBot, bot.x = posx.call(this), bot.y = 640, bot.health = 60
                }
                bot.type = type, bot.target = this._player, bot.campers = this._campers, bot.signals.dead.add(this.onActorDead, this), this._game.addChild(bot), this._enemies.push(bot)
            }, GameScene.prototype.spawnJunk = function(count) {
                for (var junk, halfw = .5 * Common.levelWidth, i = 0; i < count; ++i) junk = new Junk, junk.x = Math.random() * (halfw - -halfw) - halfw, junk.y = 620, this._game.addChild(junk), this._junk.push(junk);
                this._player.parent.addChild(this._player)
            }, GameScene.prototype.dispose = function() {}, GameScene.prototype.appear = function() {
                this.animateIn(), Common.isFirstPlay && (this.signals.pause.dispatch(this, !1), Common.isFirstPlay = !1);
                var params = new AudioParams;
                params.fadeIn = .5, Common.audio.playMusic("music_ben10_steamcamp_final", params)
            }, GameScene.prototype.show = function() {}, GameScene.prototype.animateIn = function(callback, scope) {}, GameScene.prototype.animateOut = function(callback, scope) {}, GameScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH);
                var camera = Common.camera;
                camera.bounds.x = .5 * (-Common.levelWidth + p3.View.width), camera.bounds.width = .5 * (Common.levelWidth - p3.View.width), camera.trackTarget(camera.target, !0), this._hud.resize()
            }, GameScene.prototype.update = function() {
                if (!Common.animator.paused || !this._running) {
                    Common.world.step(1 / 26);
                    var camera = Common.camera;
                    camera.targetOffset.x += .032 * (Math.abs(this._player.body.velocity[0]) * this._player.direction * 1.2 - camera.targetOffset.x), camera.update(), this._player.update(), this.updateHud();
                    var camper, i;
                    for (i = this._campers.length - 1; i >= 0; --i) camper = this._campers[i], camper.destroyNextFrame ? (camper.parent.removeChild(camper), camper.destroy(), this._campers.splice(i, 1)) : camper.update();
                    var enemy;
                    for (i = this._enemies.length - 1; i >= 0; --i) enemy = this._enemies[i], enemy.destroyNextFrame ? (enemy.parent.removeChild(enemy), enemy.destroy(), this._enemies.splice(i, 1)) : enemy.update();
                    var projectile, x, y;
                    for (i = this._projectiles.length - 1; i >= 0; --i) projectile = this._projectiles[i], x = projectile.x - camera.position.x, y = projectile.y - camera.position.y, projectile.destroyNextFrame || x < -100 || x > .5 * (Common.STAGE_WIDTH + p3.View.width) + 100 || y < -100 || y > .5 * (Common.STAGE_HEIGHT + p3.View.height) + 100 ? (projectile.parent.removeChild(projectile), projectile.destroy(), this._projectiles.splice(i, 1)) : projectile.update();
                    var powerup;
                    for (i = this._powerups.length - 1; i >= 0; --i) powerup = this._powerups[i], powerup.destroyNextFrame ? (powerup.parent.removeChild(powerup), powerup.destroy(), this._powerups.splice(i, 1)) : powerup.update();
                    var junk;
                    for (i = this._junk.length - 1; i >= 0; --i) junk = this._junk[i], junk.update();
                    var geyser;
                    for (i = this._geysers.length - 1; i >= 0; --i) geyser = this._geysers[i], geyser.update()
                }
            }, GameScene.prototype.updateHud = function() {
                this._hud.score = this._score, this._hud.campersLeft = this._campersTotal - this._campersSaved, this._hud.health = this._player.health / 100, this._hud.update()
            }, GameScene.prototype.debugDraw = function() {
                var actors = this._campers.concat(this._enemies, this._tents, this._powerups, this._junk, this._geysers, [this._player, this._safeZone]);
                this._debug.clear();
                for (var actor, i = 0; i < actors.length; ++i) actor = actors[i], actor.debugDraw(this._debug)
            }, GameScene.prototype.saveCamper = function(camper) {
                this._player.breakChain(1), camper.destroyNextFrame = !0, ++this._campersSaved;
                var points = 240 * this._multiplier;
                this._score += points, Common.currentScore = this._score;
                var camera = Common.camera,
                    position = new PIXI.Point(this._player.x - camera.position.x, this._player.y - camera.position.y);
                this._hud.addScorePopup(position, points, this._multiplier > 1), this.addMultiplier(), Common.audio.playSound("sfx_omnitrix_open_00"), Math.random() < .25 && delay(function() {
                    Common.audio.playSound("vo_ben_hehehe_00")
                }, 1, this), p3.Timestep.queueCall(function() {
                    this._campers.length <= 0 && this.end()
                }, [], this)
            }, GameScene.prototype.addMultiplier = function() {
                ++this._multiplier, this._multiplierTimer.reset(), this._multiplierTimer.start()
            }, GameScene.prototype.resetMultiplier = function() {
                this._multiplier = 1
            }, GameScene.prototype.findTentPosition = function() {
                for (var x, tent, valid, i, attempts = 1e3, halfw = .45 * Common.levelWidth; --attempts > 0;) {
                    for (x = Math.random() * (halfw - -halfw) - halfw, valid = !0, i = 0; i < this._tents.length; ++i) tent = this._tents[i], Math.abs(tent.x - x) < 280 && (valid = !1);
                    for (i = 0; i < this._geysers.length; ++i) tent = this._geysers[i], Math.abs(tent.x - x) < 420 && (valid = !1);
                    if (Math.abs(this._safeZone.x - x) < 420 && (valid = !1), valid) break
                }
                return attempts > 0 ? new PIXI.Point(x, 0) : .5 * Common.STAGE_WIDTH + Math.random() * (halfw - -halfw) - halfw
            }, GameScene.prototype.smashJunk = function(enemy) {
                function force(t, v, d) {
                    delay(function() {
                        t.grounded && t.body.applyForce([v.x, v.y])
                    }, d, this)
                }
                for (var junk, to, v, radius = 920, i = 0; i < this._junk.length; ++i) junk = this._junk[i], to = new p3.Vector2(enemy.x - junk.x, enemy.y - junk.y), to.lengthSq < radius * radius && (v = new p3.Vector2, v.y = Math.max(.3, 1 - Math.abs(to.x) / radius) * -2400, force.call(this, junk, v, Math.abs(to.x) / radius * .6))
            }, GameScene.prototype.shockPlayer = function(enemy) {
                var to = new p3.Vector2(this._player.x - enemy.x, this._player.y - enemy.y);
                to.normalize(1), to.scaleBy(440), this._player.body.applyImpulse([to.x, to.y]), this._player.takeDamage(8), this._player.breakChain(1);
                var camera = Common.camera;
                camera.shake(.4, 6)
            }, GameScene.prototype.onBeginContact = function(event) {
                var bodyA = event.bodyA,
                    bodyB = event.bodyB,
                    shapeA = event.shapeA,
                    shapeB = event.shapeB,
                    parentA = bodyA.parent,
                    parentB = bodyB.parent,
                    enemy = parentA instanceof Enemy && parentB == this._player ? parentA : parentB instanceof Enemy && parentA == this._player ? parentB : null;
                enemy && this.shockPlayer(enemy);
                var camper = parentB == this._player.chainHead && parentA instanceof Camper && !parentA.chained ? parentA : parentA == this._player.chainHead && parentB instanceof Camper && !parentB.chained ? parentB : null;
                camper && this._player.grab(camper), camper = bodyB == this._safeZone.body && parentA instanceof Camper && parentA == this._player.chainHead ? parentA : bodyA == this._safeZone.body && parentB instanceof Camper && parentB == this._player.chainHead ? parentB : null, camper && this.saveCamper(camper), enemy = parentA instanceof Enemy && bodyB == this._terrain ? parentA : parentB instanceof Enemy && bodyA == this._terrain ? parentB : null, enemy && (enemy.grounded = !0);
                var junk = parentA instanceof Junk && bodyB == this._terrain ? parentA : parentB instanceof Junk && bodyA == this._terrain ? parentB : null;
                junk && (junk.grounded = !0), camper = parentA instanceof Camper && bodyB == this._terrain ? parentA : parentB instanceof Camper && bodyA == this._terrain ? parentB : null, camper && (camper.grounded = !0);
                var projectile = parentA instanceof Projectile && parentB == this._player ? parentA : parentB instanceof Projectile && parentA == this._player ? parentB : null;
                if (projectile) {
                    projectile.collideWith(this._player, 16), this._player.breakChain(1);
                    var camera = Common.camera;
                    camera.shake(.4, 6)
                }
                if (parentA instanceof Camper && parentB instanceof Projectile ? (parentA.chained && this._player.breakChain(1), parentB.destroyNextFrame = !0) : parentB instanceof Camper && parentA instanceof Projectile && (parentB.chained && this._player.breakChain(1), parentA.destroyNextFrame = !0), parentA instanceof Projectile && parentB instanceof Enemy ? parentA.collideWith(parentB, 20) : parentB instanceof Projectile && parentA instanceof Enemy && parentB.collideWith(parentA, 20), parentA == this._player && shapeB == this._terrain.shapes[0] || parentB == this._player && shapeA == this._terrain.shapes[0]) {
                    var v = this._player.body.velocity;
                    if (v = Math.sqrt(v[0] * v[0] + v[1] * v[1]), v > 92) {
                        var damage = v / 34;
                        this._player.takeDamage(damage)
                    }
                }
                var powerup = parentA instanceof Powerup && parentB == this._player ? parentA : parentB instanceof Powerup && parentA == this._player ? parentB : null;
                powerup && this.collectPowerup(powerup);
                var geyser = parentA instanceof Geyser && parentB == this._player ? parentA : parentB instanceof Geyser && parentA == this._player ? parentB : null;
                geyser && (geyser.addTarget(this._player), geyser.active && this._player.breakChain(), Common.audio.playSound("sfx_stinkfly_hit_geiser_00"))
            }, GameScene.prototype.onEndContact = function(event) {
                var bodyA = event.bodyA,
                    bodyB = event.bodyB,
                    parentA = bodyA.parent,
                    parentB = bodyB.parent,
                    enemy = parentA instanceof Enemy && bodyB == this._terrain ? parentA : parentB instanceof Enemy && bodyA == this._terrain ? parentB : null;
                enemy && (enemy.grounded = !1);
                var camper = parentA instanceof Camper && bodyB == this._terrain ? parentA : parentB instanceof Camper && bodyA == this._terrain ? parentB : null;
                camper && (camper.grounded = !1);
                var junk = parentA instanceof Junk && bodyB == this._terrain ? parentA : parentB instanceof Junk && bodyA == this._terrain ? parentB : null;
                junk && (junk.grounded = !1);
                var gieser = parentA instanceof Geyser && parentB == this._player ? parentA : parentB instanceof Geyser && parentA == this._player ? parentB : null;
                gieser && gieser.removeTarget(this._player)
            }, GameScene.prototype.onProjectileFire = function(owner, projectile) {
                this._game.addChild(projectile), this._projectiles.push(projectile)
            }, GameScene.prototype.onBotAttack = function(enemy) {
                var camera = Common.camera;
                Common.inViewport(this, 240) && camera.shake(.4, 12), this.smashJunk(enemy)
            }, GameScene.prototype.onActorDead = function(actor, suicide) {
                if (actor == this._player) this.end();
                else if (actor instanceof Enemy) {
                    if (actor.destroyNextFrame = !0, !suicide) {
                        ++this._enemiesKilled;
                        var points = 40;
                        this._score += points, Common.currentScore = this._score;
                        var camera = Common.camera,
                            position = new PIXI.Point(actor.x - camera.position.x, actor.y - camera.position.y);
                        if (this._hud.addScorePopup(position, points, !1), Math.random() < .6) {
                            var types = [PowerupTypes.HEALTH, PowerupTypes.HEALTH, PowerupTypes.INVULNERABILITY];
                            this.spawnPowerup(types[Math.floor(Math.random() * types.length)], actor.position)
                        }
                    }
                    delay(function() {
                        this.spawnBot(actor.type)
                    }, 8, this)
                }
            }, GameScene.prototype.onPauseButtonClick = function() {
                this.signals.pause.dispatch(this, !0)
            }, GameScene.prototype.onJoystickInput = function(joystick, axis) {
                p3.Device.isMobile && (1 == axis.x ? (Common.input.isKeyLeft = !1, Common.input.isKeyRight = !0) : axis.x == -1 ? (Common.input.isKeyLeft = !0, Common.input.isKeyRight = !1) : (Common.input.isKeyLeft = !1, Common.input.isKeyRight = !1), 1 == axis.y ? (Common.input.isKeyUp = !1, Common.input.isKeyDown = !0) : axis.y == -1 ? (Common.input.isKeyUp = !0, Common.input.isKeyDown = !1) : (Common.input.isKeyUp = !1, Common.input.isKeyDown = !1))
            }, GameScene.prototype.onFireButton = function(button, value) {
                Common.input.isKeyFire = value
            }, GameScene.prototype.onDirectionButtonClick = function(button) {
                this._player.changeDirection()
            }, GameScene.prototype.onMultiplierTimerComplete = function(timer) {
                this.resetMultiplier()
            }, Object.defineProperty(GameScene.prototype, "score", {
                get: function() {
                    return this._score
                }
            }), Object.defineProperty(GameScene.prototype, "campersSaved", {
                get: function() {
                    return this._campersSaved
                }
            })
        }, {
            "./Actor": 1,
            "./AudioParams": 4,
            "./Camper": 8,
            "./CollisionGroups": 9,
            "./Common": 10,
            "./Enemy": 13,
            "./FlyBot": 14,
            "./Geyser": 16,
            "./GroundBot": 17,
            "./HoverBot": 19,
            "./Hud": 20,
            "./Junk": 24,
            "./Player": 26,
            "./Powerup": 27,
            "./PowerupTypes": 28,
            "./PreloaderScene": 29,
            "./Projectile": 30,
            "./SafeZone": 33,
            "./Tent": 35
        }],
        16: [function(require, module, exports) {
            "use strict";

            function Geyser() {
                Actor.call(this), this._active = !1, this._targets = [], this._timer = null, this._dormantEmitter = null, this._readyEmitter = null, this._eruptEmitter = null, this._jetEmitter = null;
                var assets = Common.assets,
                    sequence = new p3.MovieClipSequence;
                sequence.addTextures([assets.getTexture("obstacle_gieser_off")]), this.view = new p3.MovieClip(sequence), this.view.anchor = new PIXI.Point(.5, 1), this.view.looping = !1, this.addChild(this.view)
            }
            var AudioParams = require("./AudioParams"),
                Actor = require("./Actor"),
                CollisionGroups = require("./CollisionGroups"),
                Common = require("./Common");
            module.exports = Geyser, Geyser.prototype = Object.create(Actor.prototype), Geyser.prototype.constructor = Geyser, Geyser.prototype.init = function() {
                Actor.prototype.init.call(this);
                var config;
                config = Common.assets.getJSON("particle_emitter_geiser_dormant"), this._dormantEmitter = new cloudkid.Emitter(this, [Common.assets.getTexture("particle_steam_001"), Common.assets.getTexture("particle_steam_002"), Common.assets.getTexture("particle_steam_003"), Common.assets.getTexture("particle_steam_004")], config), this._dormantEmitter.emit = !0, this._dormantEmitter.updateOwnerPos(0, -12), config = Common.assets.getJSON("particle_emitter_geiser_ready"), this._readyEmitter = new cloudkid.Emitter(this, [Common.assets.getTexture("particle_steam_001"), Common.assets.getTexture("particle_steam_002"), Common.assets.getTexture("particle_steam_003"), Common.assets.getTexture("particle_steam_004")], config), this._readyEmitter.updateOwnerPos(0, -12), config = Common.assets.getJSON("particle_emitter_geiser_erupt"), this._eruptEmitter = new cloudkid.Emitter(this, [Common.assets.getTexture("particle_steam_001"), Common.assets.getTexture("particle_steam_002"), Common.assets.getTexture("particle_steam_003"), Common.assets.getTexture("particle_steam_004")], config), this._eruptEmitter.updateOwnerPos(0, -12), config = Common.assets.getJSON("particle_emitter_geiser_waterjet_00"), this._jetEmitter = new cloudkid.Emitter(this, [Common.assets.getTexture("particle_water_particle_00")], config), this._jetEmitter.updateOwnerPos(0, -12), delay(function() {
                    this.ready()
                }, 4 * Math.random(), this)
            }, Geyser.prototype.destroy = function() {
                this._dormantEmitter.destroy(), this._readyEmitter.destroy(), this._eruptEmitter.destroy(), this._jetEmitter.destroy(), this._timer && (this._timer.destroy(), this._timer = null), Actor.prototype.destroy.call(this)
            }, Geyser.prototype.createBody = function() {
                var body = new p2.Body({
                    mass: .62
                });
                body.type = p2.Body.KINEMATIC;
                var box = new p2.Box({
                    width: 100,
                    height: 480
                });
                return box.collisionGroup = CollisionGroups.GIESER, box.collisionMask = CollisionGroups.PLAYER | CollisionGroups.CAMPER, box.sensor = !0, body.addShape(box, [0, -300]), body
            }, Geyser.prototype.update = function() {
                Actor.prototype.update.call(this), this._dormantEmitter.update(p3.Timestep.deltaTime), this._readyEmitter.update(p3.Timestep.deltaTime), this._eruptEmitter.update(p3.Timestep.deltaTime), this._jetEmitter.update(p3.Timestep.deltaTime);
                for (var target, i = 0; i < this._targets.length; ++i) target = this._targets[i], this.splash(target)
            }, Geyser.prototype.addTarget = function(actor) {
                this._targets.push(actor)
            }, Geyser.prototype.removeTarget = function(actor) {
                var index = this._targets.indexOf(actor);
                this._targets.splice(index, 1)
            }, Geyser.prototype.splash = function(actor) {
                if (this._active) {
                    var to = new p3.Vector2(actor.x - this.x, actor.y - this.y),
                        sign = to.x / Math.abs(to.x);
                    actor.body.applyForce([540 * sign, -340])
                }
            }, Geyser.prototype.ready = function() {
                this._dormantEmitter.emit = !1, this._readyEmitter.emit = !0, this._eruptEmitter.emit = !1, this._jetEmitter.emit = !1, this._timer = delay(function() {
                    this.erupt()
                }, 4, this)
            }, Geyser.prototype.stop = function() {
                this._dormantEmitter.emit = !0, this._readyEmitter.emit = !1, this._eruptEmitter.emit = !1, this._jetEmitter.emit = !1, this._timer = delay(function() {
                    this.ready()
                }, 4 + 4 * Math.random(), this)
            }, Geyser.prototype.erupt = function() {
                if (!this._active) {
                    this._active = !0, this._dormantEmitter.emit = !1, this._readyEmitter.emit = !1, this._eruptEmitter.emit = !0, this._jetEmitter.emit = !0, this._timer = delay(function() {
                        this._active = !1, this.stop()
                    }, 3 + 2 * Math.random(), this);
                    var params = new AudioParams;
                    params.volume = .2, Common.inViewport(this, 240) && Common.audio.playSound("sfx_geiser_fountain_blast_00", params)
                }
            }, Geyser.prototype.debugDraw = function(graphics) {
                var box = this.body.shapes[0];
                graphics.lineStyle(2, 255), graphics.beginFill(255, .4), graphics.drawRect(this.body.position[0] + (box.position[0] - .5 * box.width), this.body.position[1] + (box.position[1] - .5 * box.height), box.width, box.height), graphics.endFill()
            }, Object.defineProperty(Actor.prototype, "active", {
                get: function() {
                    return this._active
                }
            })
        }, {
            "./Actor": 1,
            "./AudioParams": 4,
            "./CollisionGroups": 9,
            "./Common": 10
        }],
        17: [function(require, module, exports) {
            "use strict";

            function GroundBot() {
                Enemy.call(this), this.speed = 108, this.attackDistance = 40, this.fireDistance = 740, this.direction = 1, this.attackRate = 2, this.fireRate = .72, this.fireBurst = 1, this.aimRate = 5, this.moveRateMin = 2, this.moveRateMax = 2, this.waitRateMin = 1, this.waitRateMax = 1, this._attackTime = this.attackRate, this._fireTime = this.fireRate, this._fireCount = 0, this._moveTime = 0, this._waitTime = 0, this._aimTime = this.aimRate, this._camper = null, this._lastCamper = null, this._firing = !1;
                var holder = new PIXI.Container;
                holder.y = 110, this.addChild(holder), this.spine = new PIXI.spine.Spine(Common.assets.getSpineData("char_robot")), holder.addChild(this.spine), this.spine.stateData.setMixByName("idle", "walk", .06), this.spine.stateData.setMixByName("walk", "idle", .3), this.bodyOffset = new PIXI.Point(0, 18), this.signals.attack = new signals.Signal, this.signals.fire = new signals.Signal
            }
            var CollisionGroups = (require("./Actor"), require("./CollisionGroups")),
                Common = require("./Common"),
                Enemy = require("./Enemy"),
                Projectile = require("./Projectile"),
                ProjectileTypes = require("./ProjectileTypes");
            module.exports = GroundBot, GroundBot.prototype = Object.create(Enemy.prototype), GroundBot.prototype.constructor = GroundBot, GroundBot.prototype.init = function() {
                Enemy.prototype.init.call(this), this.spine.state.setAnimationByName(0, "walk", !0)
            }, GroundBot.prototype.destroy = function() {
                this.signals.fire.dispose(), Enemy.prototype.destroy.call(this)
            }, GroundBot.prototype.createBody = function() {
                var body = new p2.Body({
                    mass: .62
                });
                body.type = p2.Body.DYNAMIC, body.allowSleep = !0, body.damping = .82, body.gravityScale = 1, body.fixedRotation = !0;
                var radius = 100,
                    shape = new p2.Circle({
                        radius: radius
                    });
                shape.collisionGroup = CollisionGroups.ENEMY, shape.collisionMask = CollisionGroups.TERRAIN_FLOOR, body.addShape(shape);
                var sensor = new p2.Circle({
                    radius: radius
                });
                return sensor.collisionGroup = CollisionGroups.ENEMY, sensor.collisionMask = CollisionGroups.PROJECTILE_GOOD, sensor.sensor = !0, body.addShape(sensor), body
            }, GroundBot.prototype.update = function() {
                var to, distance;
                this._camper = this.findNearestCamper(), this._lastCamper != this._camper && (this._lastCamper && (this._lastCamper.chaser = null), this._lastCamper = this._camper, this._lastCamper && (this._lastCamper.chaser = this)), this._camper ? (to = new p3.Vector2(this._camper.x - this._body.position[0], this._camper.y - this._body.position[1]), distance = Math.abs(to.x), distance > this.attackDistance ? this._firing || (to.normalize(1), to.scaleBy(this.speed * (.5 + .5 * Math.random())), this.move(to.x, 0)) : (this.stop(), this._attackTime <= 0 ? (this._attackTime = this.attackRate, this.attack()) : this._attackTime -= p3.Timestep.deltaTime + .02 * Math.random())) : this._moveTime <= 0 ? (this.stop(), this._waitTime <= 0 ? (this._moveTime = p3.Utils.randomRange(this.moveRateMax, this.moveRateMin), this._waitTime = p3.Utils.randomRange(this.waitRateMax, this.waitRateMin), this.randomizeDirection()) : this._waitTime -= p3.Timestep.deltaTime) : this._firing || (this._moveTime -= p3.Timestep.deltaTime, this.move(this.speed * this.direction, 0)), to = new p3.Vector2(this.target.x - this._body.position[0], this.target.y - this._body.position[1]), distance = to.length, (distance < this.fireDistance || this._firing) && (this._aimTime <= 0 ? (this._firing = !0, this.stop(), this._fireTime <= 0 ? this._fireCount++ < this.fireBurst ? (this._fireTime = this.fireRate, this.fire()) : (this._fireCount = 0, this._firing = !1, this._aimTime = this.aimRate) : (this._fireTime -= p3.Timestep.deltaTime + .02 * Math.random(), this.scale.x = Math.abs(to.x) > 0 ? to.x / Math.abs(to.x) : this.scale.x)) : this._aimTime -= p3.Timestep.deltaTime + .02 * Math.random()), Enemy.prototype.update.call(this)
            }, GroundBot.prototype.attack = function() {
                if (!this._camper.chained) {
                    var direction = Math.random() < .5 ? -1 : 1,
                        force = [];
                    force[0] = 800 + 2400 * Math.random(), force[1] = 2e3 + 2400 * Math.random(), this._camper.body.applyForce([force[0] * direction, -force[1]])
                }
                this.scareCampers(), this.attackDistance = this.randomAttackDistance(), this.signals.attack.dispatch(this), Common.inViewport(this, 240) && Common.audio.playSound("sfx_robot_shoot_big_00")
            }, GroundBot.prototype.scareCampers = function() {
                for (var camper, to, radius = 16e4, i = 0; i < this.campers.length; ++i) camper = this.campers[i], to = new p3.Vector2(camper.x - this.x, camper.y - this.y), to.lengthSq < radius && camper.scare()
            }, GroundBot.prototype.fire = function() {
                var sequence = new p3.MovieClipSequence;
                sequence.addTextures([Common.assets.getTexture("projectile_claw_open"), Common.assets.getTexture("projectile_claw_closed")]);
                var speed = 8e3,
                    to = new p3.Vector2(this.target.x - this.x, this.target.y - this.y),
                    angle = Math.atan2(to.y, to.x),
                    spread = .084;
                angle += -spread + Math.random() * (spread - -spread);
                var v = [0, 0];
                v[0] = Math.cos(angle) * speed, v[1] = Math.sin(angle) * speed;
                var bullet = new Projectile(this, sequence, ProjectileTypes.BAD);
                bullet.x = this.body.position[0], bullet.y = this.body.position[1], bullet.rotation = Math.atan2(v[1], v[0]), bullet.body.applyForce(v), bullet.body.gravityScale = 0, bullet.animationSpeed = 8, bullet.looping = !0, bullet.view.play(), Common.audio.playSound("sfx_robot_shoot_small_00"), this.signals.fire.dispatch(this, bullet)
            }, GroundBot.prototype.findNearestCamper = function() {
                for (var camper, to, closest = null, closestDistance = Number.MAX_VALUE, i = 0; i < this.campers.length; ++i) camper = this.campers[i], to = new p3.Vector2(this.x - camper.x, this.y - camper.y), (null == camper.chaser || camper.chaser == this) && to.lengthSq < closestDistance && camper.x > -(.5 * Common.levelWidth) + 420 && (closest = camper, closestDistance = to.lengthSq);
                return closest
            }, GroundBot.prototype.randomAttackDistance = function() {
                return 64 + 64 * Math.random()
            }, GroundBot.prototype.playExplosionEffect = function() {
                Enemy.prototype.playExplosionEffect.call(this), Common.audio.playSound("sfx_robot_steam_explode_01")
            }, GroundBot.prototype.debugDraw = function(graphics) {
                var shape = this.body.shapes[0];
                graphics.lineStyle(2, 255, .4), graphics.beginFill(255, .2), graphics.drawCircle(this.body.position[0] + shape.position[0], this.body.position[1] + shape.position[1], shape.radius), graphics.endFill()
            }
        }, {
            "./Actor": 1,
            "./CollisionGroups": 9,
            "./Common": 10,
            "./Enemy": 13,
            "./Projectile": 30,
            "./ProjectileTypes": 31
        }],
        18: [function(require, module, exports) {
            "use strict";

            function HelpScene(paused) {
                this._paused = paused, this._panel = null, this._image = null, this._images = [], this._imageIndex = 0, this._page = null, this._pages = [], this._nextButton = null, this._previousButton = null, this._closeButton = null, this._soundButton = null, p3.Scene.call(this)
            }
            var BenButton = require("./BenButton"),
                BenMuteButton = require("./BenMuteButton"),
                Common = require("./Common");
            require("./PreloaderScene");
            module.exports = HelpScene, HelpScene.prototype = Object.create(p3.Scene.prototype), HelpScene.prototype.constructor = HelpScene, HelpScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("paused_bg"));
                this.addChild(bg);
                var str = this._paused ? Common.copy.paused[Common.language] : Common.copy.instructions[Common.language];
                "ar" != Common.language && "ru" != Common.language ? (this._titleLabel = new PIXI.extras.BitmapText(str, {
                    font: "75px Ahkio Paused",
                    align: "center"
                }), this._titleLabel.x = .5 * (Common.STAGE_WIDTH - this._titleLabel.textWidth), this._titleLabel.y = 120 - .5 * this._titleLabel.textHeight, this.addChild(this._titleLabel)) : (this._titleLabel = new PIXI.Text(str, {
                    font: "75px Arial",
                    fill: "#FFFFFF",
                    stroke: "#000000",
                    strokeThickness: 10,
                    align: "center"
                }), this._titleLabel.x = .5 * (Common.STAGE_WIDTH - this._titleLabel.width), this._titleLabel.y = 120 - .5 * this._titleLabel.height, this.addChild(this._titleLabel)), this._images = [p3.Device.isMobile ? Common.assets.getTexture("tutorial_mobile_001") : Common.assets.getTexture("tutorial_desktop_001"), p3.Device.isMobile ? Common.assets.getTexture("tutorial_mobile_002") : Common.assets.getTexture("tutorial_desktop_002"), p3.Device.isMobile ? Common.assets.getTexture("tutorial_mobile_003") : Common.assets.getTexture("tutorial_desktop_003"), p3.Device.isMobile ? Common.assets.getTexture("tutorial_mobile_004") : Common.assets.getTexture("tutorial_desktop_004")], this._image = new PIXI.Sprite(this._images[this._imageIndex]), this._image.x = .5 * Common.STAGE_WIDTH, this._image.y = 346, this._image.anchor = new PIXI.Point(.5, .5), this.addChild(this._image), this._pages = [Common.assets.getTexture("page_counter_001"), Common.assets.getTexture("page_counter_002"), Common.assets.getTexture("page_counter_003"), Common.assets.getTexture("page_counter_004")], this._page = new PIXI.Sprite(this._pages[this._imageIndex]), this._page.x = .5 * Common.STAGE_WIDTH, this._page.y = 514, this._page.anchor = new PIXI.Point(.5, .5), this.addChild(this._page);
                var states = new p3.ButtonStates;
                states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_home_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_home_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._homeButton = new BenButton(states), this._homeButton.y = 80, this._homeButton.animate = !0, this._homeButton.overSoundName = "sfx_btn_rollover_00", this._homeButton.clickSoundName = "sfx_btn_press_00", this._homeButton.signals.click.add(this.onHomeButtonClick, this), this.addChild(this._homeButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_audio_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_audio_over"), states.iconAlt = Common.assets.getTexture("btn_tertuary_icon_mute_off"), states.iconOverAlt = Common.assets.getTexture("btn_tertuary_icon_mute_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._soundButton = new BenMuteButton(states), this._soundButton.y = 80, this._soundButton.animate = !0, this._soundButton.overSoundName = "sfx_btn_rollover_00", this._soundButton.clickSoundName = "sfx_btn_press_00", this.addChild(this._soundButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_next_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_next_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._nextButton = new BenButton(states), this._nextButton.x = .5 * Common.STAGE_WIDTH + 432, this._nextButton.y = 362, this._nextButton.animate = !0, this._nextButton.overSoundName = "sfx_btn_rollover_00", this._nextButton.clickSoundName = "sfx_menu_swipe_00", this._nextButton.signals.click.add(this.onNextButtonClick, this), this.addChild(this._nextButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_back_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_back_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._previousButton = new BenButton(states), this._previousButton.x = .5 * Common.STAGE_WIDTH - 432, this._previousButton.y = 362, this._previousButton.animate = !0, this._previousButton.overSoundName = "sfx_btn_rollover_00", this._previousButton.clickSoundName = "sfx_menu_swipe_00", this._previousButton.signals.click.add(this.onPreviousButtonClick, this), this.addChild(this._previousButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_primary_large_off"), states.over = Common.assets.getTexture("btn_primary_large_over"), states.icon = Common.assets.getTexture("btn_primary_large_icon_play_off"), states.iconOver = Common.assets.getTexture("btn_primary_large_icon_play_over"), states.innerRing = Common.assets.getTexture("btn_primary_large_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_primary_large_off_ring_001"), this._closeButton = new BenButton(states), this._closeButton.y = p3.View.height - 120, this._closeButton.animate = !0, this._closeButton.overSoundName = "sfx_btn_rollover_00", this._closeButton.clickSoundName = "sfx_btn_play_00", this._closeButton.signals.click.add(this.onCloseButtonClick, this), this.addChild(this._closeButton), p3.Scene.prototype.init.call(this)
            }, HelpScene.prototype.destroy = function() {
                this._homeButton.destroy(), this._soundButton.destroy(), this._nextButton.destroy(), this._previousButton.destroy(), this._closeButton.destroy(), p3.Scene.prototype.destroy.call(this)
            }, HelpScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._homeButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 80, this._soundButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 80, this._closeButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 120
            }, HelpScene.prototype.update = function() {}, HelpScene.prototype.nextImage = function() {
                ++this._imageIndex >= this._images.length && (this._imageIndex = 0), this._image.texture = this._images[this._imageIndex], this._page.texture = this._pages[this._imageIndex]
            }, HelpScene.prototype.previousImage = function() {
                --this._imageIndex < 0 && (this._imageIndex = this._images.length - 1), this._image.texture = this._images[this._imageIndex], this._page.texture = this._pages[this._imageIndex]
            }, HelpScene.prototype.onHomeButtonClick = function(button) {
                this.signals.home.dispatch(this)
            }, HelpScene.prototype.onNextButtonClick = function(button) {
                this.nextImage()
            }, HelpScene.prototype.onPreviousButtonClick = function(button) {
                this.previousImage()
            }, HelpScene.prototype.onCloseButtonClick = function(button) {
                this.signals.next.dispatch(this)
            }
        }, {
            "./BenButton": 5,
            "./BenMuteButton": 6,
            "./Common": 10,
            "./PreloaderScene": 29
        }],
        19: [function(require, module, exports) {
            "use strict";

            function HoverBot() {
                Enemy.call(this), this.speed = 80, this.attackDistance = 240, this.fireDistance = 740, this.direction = 1, this.moveRateMin = 2, this.moveRateMax = 2, this.waitRateMin = 1, this.waitRateMax = 1, this._attacking = !1, this._moveTime = 0, this._waitTime = 0, this._attackTime = 0;
                var holder = new PIXI.Container;
                holder.y = 80, this.addChild(holder), this.spine = new PIXI.spine.Spine(Common.assets.getSpineData("char_robot_002")), this.spine.skeleton.setToSetupPose(), this.spine.skeleton.setSkin(null), this.spine.autoUpdate = !1, this.spine.scale.set(.5), holder.addChild(this.spine), this.spine.stateData.setMixByName("idle", "walk", .06), this.spine.stateData.setMixByName("walk", "idle", .3), this.spine.stateData.setMixByName("idle", "launch", .1), this.spine.stateData.setMixByName("walk", "launch", .1), this.spine.stateData.setMixByName("launch", "hover", .2), this.spine.stateData.setMixByName("hover", "land", .1), this.spine.stateData.setMixByName("land", "idle", .3), this.bodyOffset = new PIXI.Point(0, 18), this.signals.dead = new signals.Signal
            }
            var CollisionGroups = (require("./Actor"), require("./CollisionGroups")),
                Common = require("./Common"),
                Enemy = require("./Enemy");
            module.exports = HoverBot, HoverBot.prototype = Object.create(Enemy.prototype), HoverBot.prototype.constructor = HoverBot, HoverBot.prototype.init = function() {
                Enemy.prototype.init.call(this), this.spine.state.setAnimationByName(0, "idle", !0)
            }, HoverBot.prototype.createBody = function() {
                var body = new p2.Body({
                    mass: .62
                });
                body.type = p2.Body.DYNAMIC, body.allowSleep = !0, body.damping = .82, body.gravityScale = 1, body.fixedRotation = !0;
                var radius = 70,
                    shape = new p2.Circle({
                        radius: radius
                    });
                shape.collisionGroup = CollisionGroups.ENEMY, shape.collisionMask = CollisionGroups.TERRAIN_FLOOR, body.addShape(shape);
                var sensor = new p2.Circle({
                    radius: radius
                });
                return sensor.collisionGroup = CollisionGroups.ENEMY, sensor.collisionMask = CollisionGroups.PLAYER | CollisionGroups.PROJECTILE_GOOD, sensor.sensor = !0, body.addShape(sensor), body
            }, HoverBot.prototype.update = function() {
                Enemy.prototype.update.call(this);
                var to = new p3.Vector2(this.target.x - this._body.position[0], this.target.y - this._body.position[1]),
                    distance = Math.abs(to.x);
                this._attacking ? this.body.applyForce([0, -260]) : this.grounded && (distance > this.attackDistance ? this._moveTime <= 0 ? (this.stop(), this._waitTime <= 0 ? (this._moveTime = p3.Utils.randomRange(this.moveRateMax, this.moveRateMin), this._waitTime = p3.Utils.randomRange(this.waitRateMax, this.waitRateMin), this.randomizeDirection()) : this._waitTime -= p3.Timestep.deltaTime) : (this._moveTime -= p3.Timestep.deltaTime, this.move(this.speed * this.direction, 0)) : (this.stop(), this._attackTime <= 0 && (this._attackTime = 2, this.attack())), this._attackTime -= p3.Timestep.deltaTime), this.spine.update(p3.Timestep.deltaTime)
            }, HoverBot.prototype.attack = function() {
                this._attacking || (this._attacking = !0, delay(function() {
                    this._attacking = !1
                }, 1.2, this), delay(function() {
                    this.spine.state.setAnimationByName(0, "land", !1), this.spine.state.addAnimationByName(0, "idle", !0, 0)
                }, 4.1, this), this.spine.state.setAnimationByName(0, "launch", !1), Common.inViewport(this, 240) && Common.audio.playSound("sfx_robot_stop_00"))
            }, HoverBot.prototype.takeDamage = function(value, source, animate) {
                Enemy.prototype.takeDamage.call(this, value, source, animate), this.dead && Common.audio.playSound("sfx_robot_steam_explode_00")
            }, HoverBot.prototype.playExplosionEffect = function() {
                Enemy.prototype.playExplosionEffect.call(this), Common.audio.playSound("sfx_robot_steam_explode_00")
            }, HoverBot.prototype.debugDraw = function(graphics) {
                var shape = this.body.shapes[0];
                graphics.lineStyle(2, 255, .4), graphics.beginFill(255, .2), graphics.drawCircle(this.body.position[0] + shape.position[0], this.body.position[1] + shape.position[1], shape.radius), graphics.endFill()
            }
        }, {
            "./Actor": 1,
            "./CollisionGroups": 9,
            "./Common": 10,
            "./Enemy": 13
        }],
        20: [function(require, module, exports) {
            "use strict";

            function Hud() {
                PIXI.Container.call(this), this.signals = {}, this.signals.pause = new signals.Signal, this.signals.fire = new signals.Signal, this.signals.direction = new signals.Signal, this._camperText = new PIXI.extras.BitmapText("0", {
                    font: "25px Ahkio General",
                    align: "center"
                }), this._camperText.y = 60, this._camperText.value = 0, this.addChild(this._camperText), this._score = this.createScore(), this._score.y = 56, this._score.value = 0, this.addChild(this._score), this._health = this.createHealth(), this._health.y = 56, this._health.value = 1, this.addChild(this._health), this._saved = this.createSaved(), this._saved.y = 56, this._saved.value = 0, this.addChild(this._saved);
                var states = new p3.ButtonStates;
                states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_pause_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_pause_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._pauseButton = new BenButton(states), this._pauseButton.y = 80, this._pauseButton.animate = !0, this._pauseButton.overSoundName = "sfx_btn_rollover_00", this._pauseButton.clickSoundName = "sfx_btn_press_00", this._pauseButton.signals.click.add(this.onPauseButtonClick, this), this.addChild(this._pauseButton), this._scoreSmooth = this._score.value, this.updateScore(this._scoreSmooth), this._savedSmooth = this._saved.value, this.updateSaved(this._savedSmooth), this._healthSmooth = this._health.value, this.updateHealth(this._healthSmooth), this._joystick = new Joystick, this._joystick.y = .5 * (Common.STAGE_HEIGHT + p3.View.height - this._joystick.height) - 114, this._joystick.visible = p3.Device.isMobile, this.addChild(this._joystick), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_shoot"), this._fireButton = new p3.Button(states), this._fireButton.y = .5 * (Common.STAGE_HEIGHT + p3.View.height - this._joystick.height) - 114, this._fireButton.visible = p3.Device.isMobile, this._fireButton.signals.down.add(this.onFireButtonDown, this), this._fireButton.signals.up.add(this.onFireButtonUp, this), this.addChild(this._fireButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_rotate"), this._directionButton = new p3.Button(states), this._directionButton.y = .5 * (Common.STAGE_HEIGHT + p3.View.height - this._joystick.height) - 114, this._directionButton.visible = p3.Device.isMobile, this._directionButton.signals.click.add(this.onDirectionButtonClick, this), this.addChild(this._directionButton)
            }
            var BenButton = require("./BenButton"),
                Common = (require("./BenMuteButton"), require("./Common")),
                Joystick = require("./Joystick");
            module.exports = Hud, Hud.prototype = Object.create(PIXI.Container.prototype), Hud.prototype.constructor = Hud, Hud.prototype.destroy = function() {
                this._joystick.destroy(), PIXI.Container.prototype.destroy.call(this)
            }, Hud.prototype.resize = function() {
                this._score.x = .5 * (Common.STAGE_WIDTH - p3.View.width + this._score.width) + 20, this._saved.x = .5 * (Common.STAGE_WIDTH + p3.View.width - this._saved.width) - 180, this._health.x = .5 * Common.STAGE_WIDTH - 40, this._pauseButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 80, this._joystick.x = .5 * (Common.STAGE_WIDTH - p3.View.width + 360) + 40, this._joystick.resize(), this._fireButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width - this._fireButton.width) - 120, this._directionButton.x = this._fireButton.x - .5 * (this._fireButton.width + this._directionButton.width) - 114
            }, Hud.prototype.update = function() {
                this._scoreSmooth += .42 * (this._score.value - this._scoreSmooth), this.updateScore(this._scoreSmooth), this._savedSmooth += .42 * (this._saved.value - this._savedSmooth), this.updateSaved(this._savedSmooth), this._healthSmooth += .24 * (this._health.value - this._healthSmooth), this.updateHealth(this._healthSmooth), this._joystick.update()
            }, Hud.prototype.createScore = function() {
                var score = new PIXI.Sprite(Common.assets.getTexture("ui_score"));
                return score.anchor = new PIXI.Point(.5, .5), score.label = new PIXI.extras.BitmapText("0", {
                    font: "25px Ahkio General",
                    align: "center"
                }), score.addChild(score.label), score
            }, Hud.prototype.createHealth = function() {
                var health = new PIXI.Sprite(Common.assets.getTexture("ui_health_bar"));
                return health.anchor = new PIXI.Point(.5, .5), health.bar = new PIXI.Sprite(Common.assets.getTexture("ui_health_fill")), health.bar.anchor = new PIXI.Point(.5, .5), health.addChild(health.bar), health.bar.mask = new PIXI.Graphics, health.bar.mask.x = .5 * -health.bar.width, health.bar.mask.y = .5 * -health.bar.height, health.bar.mask.beginFill(16711680), health.bar.mask.drawRect(0, 0, health.bar.width, health.bar.height), health.bar.mask.endFill(), health.addChild(health.bar.mask), health.avatar = new PIXI.Sprite(Common.assets.getTexture("ui_health_icon")), health.avatar.x = .5 * -health.width - 20, health.avatar.anchor = new PIXI.Point(.5, .5), health.addChild(health.avatar), health
            }, Hud.prototype.createSaved = function() {
                var saved = new PIXI.Sprite(Common.assets.getTexture("ui_saved"));
                return saved.anchor = new PIXI.Point(.5, .5), saved.label = new PIXI.extras.BitmapText("0", {
                    font: "25px Ahkio General",
                    align: "center"
                }), saved.addChild(saved.label), saved
            }, Hud.prototype.addScorePopup = function(position, value, multiplier) {
                var holder = new PIXI.Container;
                holder.x = position.x, holder.y = position.y, this.addChild(holder);
                var text = new PIXI.extras.BitmapText("+" + value.toString(), {
                    font: "48px Ahkio Orange",
                    align: "center"
                });
                text.x = .5 * -text.textWidth, text.y = .5 * -text.textHeight, holder.addChild(text);
                var tl = new TimelineMax({
                    onComplete: function(text) {
                        text.parent.removeChild(text), text.destroy()
                    },
                    onCompleteParams: [holder],
                    onCompleteScope: this
                });
                multiplier ? (holder.scale = new PIXI.Point, tl.insert(TweenMax.to(holder.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [6]
                })), tl.insert(TweenMax.to(holder, .2, {
                    delay: .4,
                    alpha: 0,
                    ease: Power1.easeInOut
                }))) : (holder.alpha = 0, tl.insert(TweenMax.to(holder, .2, {
                    alpha: 1,
                    ease: Power1.easeInOut
                })), tl.insert(TweenMax.to(holder, .6, {
                    y: holder.y - 60,
                    ease: Power1.easeIn
                })), tl.insert(TweenMax.to(holder, .2, {
                    delay: .4,
                    alpha: 0,
                    ease: Power1.easeInOut
                })))
            }, Hud.prototype.showLevelBanner = function() {
                var banner = new PIXI.Sprite(Common.assets.getTexture("level_panel"));
                banner.x = .5 * Common.STAGE_WIDTH, banner.y = 340, banner.anchor = new PIXI.Point(.5, .5), banner.visible = !1, this.addChild(banner), "ar" != Common.language && "ru" != Common.language ? (banner.label = new PIXI.extras.BitmapText(Common.copy.level[Common.language].replace("[LEVEL]", Common.level + 1), {
                    font: "100px Ahkio Green",
                    align: "center"
                }), banner.label.x = .5 * -banner.label.textWidth, banner.label.y = .5 * -banner.label.textHeight, banner.addChild(banner.label)) : (banner.label = new PIXI.Text(Common.copy.level[Common.language].replace("[LEVEL]", Common.level + 1), {
                    font: "100px Arial",
                    fill: "#69FF00",
                    stroke: "#044300",
                    strokeThickness: 10,
                    align: "center"
                }), banner.label.x = .5 * -banner.label.width, banner.label.y = .5 * -banner.label.height, banner.addChild(banner.label));
                var tl = new TimelineMax;
                banner.scale = new PIXI.Point, tl.append(TweenMax.to(banner.scale, .34, {
                    delay: .6,
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2],
                    onStart: function() {
                        banner.visible = !0, banner.scale = new PIXI.Point(.5, .5)
                    }
                })), tl.append(TweenMax.to(banner, .2, {
                    delay: 1.4,
                    alpha: 0,
                    ease: Power1.easeOut
                })), Common.animator.add(tl)
            }, Hud.prototype.updateScore = function(value) {
                this._score.label.text = Math.round(value).toString(), this._score.label.validate(), this._score.label.x = 18 - .5 * this._score.label.textWidth, this._score.label.y = .5 * -this._score.label.textHeight
            }, Hud.prototype.updateSaved = function(value) {
                this._saved.label.text = Math.round(value), this._saved.label.validate(), this._saved.label.x = 18 - .5 * this._saved.label.textWidth, this._saved.label.y = .5 * -this._saved.label.textHeight
            }, Hud.prototype.updateHealth = function(value) {
                value = Math.min(1, Math.max(0, value)), this._health.bar.mask.scale.x = value
            }, Hud.prototype.onPauseButtonClick = function(button) {
                this.signals.pause.dispatch(this)
            }, Hud.prototype.onFireButtonDown = function(button) {
                this.signals.fire.dispatch(this, !0)
            }, Hud.prototype.onFireButtonUp = function(button) {
                this.signals.fire.dispatch(this, !1)
            }, Hud.prototype.onDirectionButtonClick = function(button) {
                this.signals.direction.dispatch(this)
            }, Object.defineProperty(Hud.prototype, "score", {
                get: function() {
                    return this._score.value
                },
                set: function(value) {
                    this._score.value = value
                }
            }), Object.defineProperty(Hud.prototype, "campersLeft", {
                get: function() {
                    return this._saved.value
                },
                set: function(value) {
                    this._saved.value = value
                }
            }), Object.defineProperty(Hud.prototype, "health", {
                get: function() {
                    return this._health.value
                },
                set: function(value) {
                    this._health.value = value
                }
            }), Object.defineProperty(Hud.prototype, "joystick", {
                get: function() {
                    return this._joystick
                }
            })
        }, {
            "./BenButton": 5,
            "./BenMuteButton": 6,
            "./Common": 10,
            "./Joystick": 23
        }],
        21: [function(require, module, exports) {
            "use strict";

            function Input() {
                this.isKeyUp = !1, this.isKeyLeft = !1, this.isKeyRight = !1, this.isKeyDown = !1, this.isKeyFire = !1, this.isKeyAltFire = !1, this.touch = new PIXI.Point, this.isTouch = !1, this.signals = {}, this.signals.mouseMove = new signals.Signal, this.signals.mouseDown = new signals.Signal, this.signals.mouseUp = new signals.Signal, this.signals.mouseClick = new signals.Signal, this.signals.keyDown = new signals.Signal, this.signals.keyUp = new signals.Signal, this._stage = null
            }
            module.exports = Input, Input.keys = {}, Input.keys.W = 87, Input.keys.A = 65, Input.keys.S = 83, Input.keys.D = 68, Input.keys.Z = 90, Input.keys.X = 88, Input.keys.C = 67, Input.keys.SPACE = 32, Input.keys.LEFT = 37, Input.keys.RIGHT = 39, Input.keys.UP = 38, Input.keys.DOWN = 40, Input.prototype.init = function(stage, keyListener) {
                this._stage = stage, this._stage.interactive = !0, this._stage.mousemove = this._stage.touchmove = this.onMouseMove.bind(this), this._stage.mousedown = this._stage.touchstart = this.onMouseDown.bind(this), this._stage.mouseup = this._stage.touchend = this.onMouseUp.bind(this), this._stage.click = this._stage.tap = this.onMouseClick.bind(this), keyListener.onkeydown = this.onKeyDown.bind(this), keyListener.onkeyup = this.onKeyUp.bind(this), setInterval(function() {
                    keyListener.focus()
                }, 1e3)
            }, Input.prototype.dispose = function() {
                this._stage.mousemove = this._stage.touchmove = null, this._stage.mousedown = this._stage.touchstart = null, this._stage.mouseup = this._stage.touchend = null, this._stage.click = this._stage.tap = null, this.signals.mouseMove.dispose(), this.signals.mouseDown.dispose(), this.signals.mouseUp.dispose(), this.signals.mouseClick.dispose(), this.signals.keyDown.dispose(), this.signals.keyUp.dispose()
            }, Input.prototype.onMouseMove = function(event) {
                this.touch = event.data.getLocalPosition(this._stage), p3.Timestep.queueCall(function() {
                    this.signals.mouseMove.dispatch(event)
                }, [], this)
            }, Input.prototype.onMouseDown = function(event) {
                this.touch = event.data.getLocalPosition(this._stage), this.isTouch = !0, p3.Timestep.queueCall(function() {
                    this.signals.mouseDown.dispatch(event)
                }, [], this)
            }, Input.prototype.onMouseUp = function(event) {
                this.touch = event.data.getLocalPosition(this._stage), this.isTouch = !1, p3.Timestep.queueCall(function() {
                    this.signals.mouseUp.dispatch(event)
                }, [], this)
            }, Input.prototype.onMouseClick = function(event) {
                p3.Timestep.queueCall(function() {
                    this.signals.mouseClick.dispatch(event)
                }, [], this)
            }, Input.prototype.onKeyDown = function(event) {
                switch (event.preventDefault(), event.keyCode) {
                    case Input.keys.UP:
                    case Input.keys.W:
                        this.isKeyUp = !0;
                        break;
                    case Input.keys.LEFT:
                    case Input.keys.A:
                        this.isKeyLeft = !0;
                        break;
                    case Input.keys.RIGHT:
                    case Input.keys.D:
                        this.isKeyRight = !0;
                        break;
                    case Input.keys.DOWN:
                    case Input.keys.S:
                        this.isKeyDown = !0;
                        break;
                    case Input.keys.Z:
                    case Input.keys.SPACE:
                        this.isKeyFire = !0;
                        break;
                    case Input.keys.X:
                        this.isKeyAltFire = !0
                }
                p3.Timestep.queueCall(function() {
                    this.signals.keyDown.dispatch(event)
                }, [], this)
            }, Input.prototype.onKeyUp = function(event) {
                switch (event.preventDefault(), event.keyCode) {
                    case Input.keys.UP:
                    case Input.keys.W:
                        this.isKeyUp = !1;
                        break;
                    case Input.keys.LEFT:
                    case Input.keys.A:
                        this.isKeyLeft = !1;
                        break;
                    case Input.keys.RIGHT:
                    case Input.keys.D:
                        this.isKeyRight = !1;
                        break;
                    case Input.keys.DOWN:
                    case Input.keys.S:
                        this.isKeyDown = !1;
                        break;
                    case Input.keys.Z:
                    case Input.keys.SPACE:
                        this.isKeyFire = !1;
                        break;
                    case Input.keys.X:
                        this.isKeyAltFire = !1
                }
                p3.Timestep.queueCall(function() {
                    this.signals.keyUp.dispatch(event)
                }, [], this)
            }
        }, {}],
        22: [function(require, module, exports) {
            "use strict";

            function IntroScene() {
                this._homeButton = null, this._nextButton = null, this._soundButton = null, this._image = null, this._images = [], this._imageIndex = 0, p3.Scene.call(this)
            }
            var BenButton = require("./BenButton"),
                BenMuteButton = require("./BenMuteButton"),
                Common = require("./Common"),
                PreloaderScene = require("./PreloaderScene");
            module.exports = IntroScene, IntroScene.prototype = Object.create(p3.Scene.prototype), IntroScene.prototype.constructor = IntroScene, IntroScene.prototype.preloader = function() {
                return new PreloaderScene
            }, IntroScene.prototype.load = function() {
                return [{
                    name: "intro_001",
                    url: "images/intro_001.jpg"
                }, {
                    name: "intro_002",
                    url: "images/intro_002.jpg"
                }, {
                    name: "intro_003",
                    url: "images/intro_003.jpg"
                }]
            }, IntroScene.prototype.unload = function() {
                Common.assets
            }, IntroScene.prototype.init = function() {
                p3.Scene.prototype.init.call(this), this._images = ["intro_001", "intro_002", "intro_003"], this._image = new PIXI.Sprite(PIXI.Texture.EMPTY), this.addChild(this._image);
                var states = new p3.ButtonStates;
                states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_home_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_home_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._homeButton = new BenButton(states), this._homeButton.y = 80, this._homeButton.animate = !0, this._homeButton.overSoundName = "sfx_btn_rollover_00", this._homeButton.clickSoundName = "sfx_btn_back", this._homeButton.signals.click.add(this.onHomeButtonClick, this), this.addChild(this._homeButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_primary_large_off"), states.over = Common.assets.getTexture("btn_primary_large_over"), states.icon = Common.assets.getTexture("btn_primary_large_icon_play_off"), states.iconOver = Common.assets.getTexture("btn_primary_large_icon_play_over"), states.innerRing = Common.assets.getTexture("btn_primary_large_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_primary_large_off_ring_002"), this._nextButton = new BenButton(states), this._nextButton.y = p3.View.height - 100, this._nextButton.animate = !0, this._nextButton.overSoundName = "sfx_btn_rollover_00", this._nextButton.clickSoundName = "sfx_btn_play_00", this._nextButton.signals.click.add(this.onNextButtonClick, this), this.addChild(this._nextButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_audio_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_audio_over"), states.iconAlt = Common.assets.getTexture("btn_tertuary_icon_mute_off"), states.iconOverAlt = Common.assets.getTexture("btn_tertuary_icon_mute_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._soundButton = new BenMuteButton(states), this._soundButton.y = 80, this._soundButton.animate = !0, this._soundButton.overSoundName = "sfx_btn_rollover_00", this._soundButton.clickSoundName = "sfx_btn_press_00", this.addChild(this._soundButton), this.showNext()
            }, IntroScene.prototype.destroy = function() {
                this._homeButton.destroy(), this._nextButton.destroy(), this._soundButton.destroy(), p3.Scene.prototype.destroy.call(this)
            }, IntroScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._homeButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 80, this._nextButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 100, this._soundButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 80
            }, IntroScene.prototype.update = function() {}, IntroScene.prototype.showNext = function() {
                this._image.texture = Common.assets.getTexture(this._images[this._imageIndex++]), this._image.x = .5 * (Common.STAGE_WIDTH - this._image.width)
            }, IntroScene.prototype.onHomeButtonClick = function(button) {
                this.signals.home.dispatch(this)
            }, IntroScene.prototype.onNextButtonClick = function(button) {
                this._imageIndex < this._images.length ? this.showNext() : this.signals.next.dispatch(this)
            }, IntroScene.prototype.onCloseButtonClick = function(button) {
                this.signals.next.dispatch(this)
            }
        }, {
            "./BenButton": 5,
            "./BenMuteButton": 6,
            "./Common": 10,
            "./PreloaderScene": 29
        }],
        23: [function(require, module, exports) {
            "use strict";

            function Joystick() {
                PIXI.Container.call(this), this.signals = {}, this.signals.input = new signals.Signal, this.deadzone = 16, this._active = !1, this._padding = new PIXI.Graphics, this.addChild(this._padding), this._area = new PIXI.Sprite(Common.assets.getTexture("btn_joystick_pad")), this._area.anchor = new PIXI.Point(.5, .5), this.addChild(this._area), this._thumb = new PIXI.Sprite(Common.assets.getTexture("btn_joystick_stick")), this._thumb.x = 2, this._thumb.y = 2, this._thumb.anchor = new PIXI.Point(.5, .5), this.addChild(this._thumb), this._axis = new PIXI.Point, this.interactive = !0;
                var that = this;
                this.mousedown = this.touchstart = function() {
                    that.onMouseDown.call(that)
                }, this._padding.interactive = !0, this._padding.mouseup = this._padding.touchend = function() {
                    that.onMouseUp.call(that)
                }
            }
            var Common = require("./Common");
            module.exports = Joystick, Joystick.prototype = Object.create(PIXI.Container.prototype), Joystick.prototype.constructor = Joystick, Joystick.prototype.destroy = function() {
                Common.input.signals.mouseUp.remove(this.onMouseUp, this), PIXI.Container.prototype.destroy.call(this)
            }, Joystick.prototype.resize = function() {
                this._padding.clear(), this._padding.beginFill(16711680, 0), this._padding.drawRect(-this.x + .5 * (Common.STAGE_WIDTH - p3.View.width), -this.y, .6 * p3.View.width, p3.View.height), this._padding.endFill()
            }, Joystick.prototype.update = function() {
                var target = new PIXI.Point;
                this._active && (target = this.toLocal(new PIXI.Point(Common.input.touch.x, Common.input.touch.y), Common.stage));
                var ease = .44;
                this._thumb.x += (target.x - this._thumb.x) * ease, this._thumb.y += (target.y - this._thumb.y) * ease;
                var distance = Math.sqrt(this._thumb.x * this._thumb.x + this._thumb.y * this._thumb.y),
                    angle = Math.atan2(this._thumb.y, this._thumb.x),
                    radius = 80;
                distance > radius && (this._thumb.x = Math.cos(angle) * radius, this._thumb.y = Math.sin(angle) * radius), this._axis.x = 0 != this._thumb.x && Math.abs(this._thumb.x) > this.deadzone ? this._thumb.x / Math.abs(this._thumb.x) : 0, this._axis.y = 0 != this._thumb.y && Math.abs(this._thumb.y) > this.deadzone ? this._thumb.y / Math.abs(this._thumb.y) : 0, this.active && (distance > this.deadzone ? this.signals.input.dispatch(this, this._axis.clone()) : this.signals.input.dispatch(this, new PIXI.Point))
            }, Joystick.prototype.onMouseDown = function(event) {
                this._active = !0
            }, Joystick.prototype.onMouseUp = function(event) {
                this._active = !1, this.signals.input.dispatch(this, new PIXI.Point)
            }, Object.defineProperty(Joystick.prototype, "active", {
                get: function() {
                    return this._active
                }
            }), Object.defineProperty(Joystick.prototype, "axis", {
                get: function() {
                    return this._axis
                }
            })
        }, {
            "./Common": 10
        }],
        24: [function(require, module, exports) {
            "use strict";

            function Junk() {
                this.grounded = !1, this._radius = 0;
                var type = Math.floor(6 * Math.random()),
                    sequence = new p3.MovieClipSequence;
                switch (type) {
                    case 0:
                        this._radius = 8, sequence.addTextures([Common.assets.getTexture("scenery_boulder_001")]);
                        break;
                    case 1:
                        this._radius = 12, sequence.addTextures([Common.assets.getTexture("scenery_boulder_002")]);
                        break;
                    case 2:
                        this._radius = 8, sequence.addTextures([Common.assets.getTexture("scenery_boulder_003")]);
                        break;
                    case 3:
                        this._radius = 8, sequence.addTextures([Common.assets.getTexture("scenery_boulder_004")]);
                        break;
                    case 4:
                        this._radius = 8, sequence.addTextures([Common.assets.getTexture("scenery_boulder_005")]);
                        break;
                    case 5:
                        this._radius = 16, sequence.addTextures([Common.assets.getTexture("scenery_basket")])
                }
                Actor.call(this), this.view = new p3.MovieClip(sequence), this.view.anchor = new PIXI.Point(.5, .5), this.addChild(this.view)
            }
            var Actor = require("./Actor"),
                CollisionGroups = require("./CollisionGroups"),
                Common = require("./Common");
            module.exports = Junk, Junk.prototype = Object.create(Actor.prototype), Junk.prototype.constructor = Junk, Junk.prototype.init = function() {
                Actor.prototype.init.call(this), this.view.gotoAndStop(Math.random() * this.view.totalFrames)
            }, Junk.prototype.createBody = function() {
                var body = new p2.Body({
                    mass: .62
                });
                body.type = p2.Body.DYNAMIC, body.allowSleep = !1, body.gravityScale = 1.6, body.fixedRotation = !0;
                var shape = new p2.Circle({
                    radius: this._radius
                });
                return shape.collisionGroup = CollisionGroups.JUNK, shape.collisionMask = CollisionGroups.TERRAIN_FLOOR | CollisionGroups.JUNK, body.addShape(shape), body
            }, Junk.prototype.debugDraw = function(graphics) {
                var shape = this.body.shapes[0];
                graphics.lineStyle(2, 16711680, .4), graphics.beginFill(16711680, .2), graphics.drawCircle(this.body.position[0] + shape.position[0], this.body.position[1] + shape.position[1], shape.radius), graphics.endFill()
            }
        }, {
            "./Actor": 1,
            "./CollisionGroups": 9,
            "./Common": 10
        }],
        25: [function(require, module, exports) {
            "use strict";

            function Main(width, height) {
                this._width = width, this._height = height, this._preloader = null, this._game = null
            }
            var Application = require("./Application"),
                AudioManager = require("./AudioManager"),
                Common = require("./Common"),
                Input = require("./Input"),
                CNPreloaderScene = require("./CNPreloaderScene");
            window.Main = Main, Main.prototype.init = function() {
                var params = new p3.ViewParams;
                params.holderId = "game", params.width = this._width, params.height = this._height, params.rotateImageUrl = "./assets/images/localisation/rotate_" + Common.language + ".jpg", params.rotateImageColor = "#000000", PIXI.RETINA_PREFIX = /\_(?=[^_]*$)(.+)x/, p3.Device.init(window.bowser), TweenMax.defaultOverwrite = "none", TweenMax.ticker.fps(60), Common.assets = p3.AssetManager.instance, Common.audio = p3.Button.audio = new AudioManager, Common.language = language;
                var view = new p3.View(params);
                view.signals.ready.addOnce(function(canvas) {
                    var options = {};
                    options.view = canvas, options.transparent = !1, options.antialias = !1, options.preserveDrawingBuffer = !1, options.resolution = 1;
                    var stage = new PIXI.Container;
                    Common.stage = stage;
                    var input = new Input;
                    input.init(stage, canvas), Common.input = input, p3.Device.isCocoonJS && (stage.scale.x = window.innerHeight / params.height, stage.scale.y = window.innerHeight / params.height);
                    var renderer = p3.Device.isCocoonJS ? new PIXI.WebGLRenderer(window.innerWidth, window.innerHeight, options) : PIXI.autoDetectRenderer(this._width, this._height, options);
                    renderer.backgroundColor = 0, Common.renderer = renderer, Common.isWebGL = renderer instanceof PIXI.WebGLRenderer;
                    var sm = new p3.SceneManager(renderer);
                    Common.scene = sm, Common.stage.addChild(sm.view);
                    var timestep = new p3.Timestep(p3.Timestep.FIXED);
                    timestep.init(this.update, this.render, this), Common.timestep = timestep, Common.animator = new p3.Animator, Common.animator.init(), window.delay = function(callback, delay, scope) {
                        return Common.animator.setTimeout(callback, delay, scope)
                    }, this.loadPreloader()
                }, this), view.signals.resize.add(this.onCanvasResize, this), Common.view = view
            }, Main.prototype.loadPreloader = function() {
                var files = [{
                        name: "preloader_bg",
                        url: "images/preloader_bg.jpg"
                    }, {
                        name: "preloader_0",
                        url: "images/preloader_0.json"
                    }, {
                        name: "cn_preloader_bg",
                        url: "images/cn_preloader_bg.jpg"
                    }, {
                        name: "cn_preloader",
                        url: "images/cn_preloader.json"
                    }, {
                        name: "particles_0",
                        url: "images/particles_0.json"
                    }, {
                        name: "preloader_radial_spray",
                        url: "particles/preloader_radial_spray.json"
                    }, {
                        name: "particle_emitter_player_hit_00",
                        url: "particles/particle_emitter_player_hit_00.json"
                    }, {
                        name: "particle_emitter_robot_explode_00",
                        url: "particles/particle_emitter_robot_explode_00.json"
                    }, {
                        name: "particle_emitter_explosion_smoke_00",
                        url: "particles/particle_emitter_explosion_smoke_00.json"
                    }, {
                        name: "particle_emitter_explosion_big_smoke_00",
                        url: "particles/particle_emitter_explosion_big_smoke_00.json"
                    }, {
                        name: "particle_transform_pickup_attract_add_00",
                        url: "particles/particle_transform_pickup_attract_add_00.json"
                    }, {
                        name: "particle_emitter_geiser_dormant",
                        url: "particles/particle_emitter_geiser_dormant.json"
                    }, {
                        name: "particle_emitter_geiser_ready",
                        url: "particles/particle_emitter_geiser_ready.json"
                    }, {
                        name: "particle_emitter_geiser_erupt",
                        url: "particles/particle_emitter_geiser_erupt.json"
                    }, {
                        name: "particle_emitter_geiser_waterjet_00",
                        url: "particles/particle_emitter_geiser_waterjet_00.json"
                    }, {
                        name: "ahkio_25_general",
                        url: "fonts/ahkio_25_general.xml"
                    }, {
                        name: "ahkio_60_white_endgame",
                        url: "fonts/ahkio_60_white_endgame.xml"
                    }, {
                        name: "ahkio_75_paused",
                        url: "fonts/ahkio_75_paused.xml"
                    }, {
                        name: "ahkio_90_orange_endgame",
                        url: "fonts/ahkio_90_orange_endgame.xml"
                    }, {
                        name: "ahkio_100_green_endgame",
                        url: "fonts/ahkio_100_green_endgame.xml"
                    }],
                    sounds = [];
                files.length ? (Common.assets.addFiles(files, "assets/"), Common.assets.signals.complete.addOnce(function() {
                    this.loadAssets()
                }, this), Common.assets.load(), Common.audio.addSounds(sounds, [".mp3", ".ogg"], "")) : this.loadAssets()
            }, Main.prototype.loadAssets = function() {
                var files = [{
                        name: "bg_splash",
                        url: "images/bg_splash.jpg"
                    }, {
                        name: "paused_bg",
                        url: "images/paused_bg.jpg"
                    }, {
                        name: "copy",
                        url: "data/languages.json"
                    }, {
                        name: "title",
                        url: "images/localisation/title_" + Common.language + ".png"
                    }, {
                        name: "buttons",
                        url: "images/buttons.json"
                    }, {
                        name: "ui_0",
                        url: "images/ui_0.json"
                    }, {
                        name: "config",
                        url: "data/config.json"
                    }],
                    sounds = ["music_end_quiet_00", "music_main_fullloop_quiet_00", "music_ben10_steamcamp_final", "sfx_btn_back", "sfx_btn_play_00", "sfx_btn_press_00", "sfx_btn_rollover_00", "sfx_menu_swipe_00", "sfx_stinkfly_shoot_02", "sfx_stinkfly_holdperson_01", "sfx_stinkfly_changedirection_00", "sfx_omnitrix_open_00", "sfx_omnitrix_transform_00", "sfx_omnitrix_transform_back_00", "sfx_stinkfly_flap_00", "sfx_robot_shoot_big_00", "sfx_robot_shoot_small_00", "sfx_robot_start_00", "sfx_robot_stop_00", "sfx_stinkfly_gasattack_00", "sfx_stinkfly_gasattack_01", "sfx_stinkfly_gloophit_00", "sfx_stinkfly_hit_geiser_00", "sfx_ben_orb", "sfx_robot_steam_explode_00", "sfx_robot_steam_explode_01", "sfx_geiser_fountain_blast_00", "vo_ben_lift_00", "vo_ben_win_haaa_00", "vo_ben_woohoo_00", "vo_ben_hehehe_00", "vo_ben_hurt_00", "vo_ben_oohoof_00", "vo_ben_release_00", "vo_ben_whoa_00"];
                files.length ? (this._preloader = new CNPreloaderScene, Common.scene.add(this._preloader), Common.assets.addFiles(files, "assets/"), Common.assets.signals.progress.add(this.onLoadingProgress, this), Common.assets.signals.complete.addOnce(this.onLoadingCompleted, this), Common.assets.load(), Common.audio.addSounds(sounds, [".mp3", ".ogg"], "assets/audio/")) : this.startGame()
            }, Main.prototype.startGame = function() {
                this._game = new Application, this._game.init()
            }, Main.prototype.update = function() {
                Common.scene.update(), Common.animator.update()
            }, Main.prototype.render = function() {
                Common.renderer.render(Common.stage)
            }, Main.prototype.onLoadingProgress = function(event) {
                this._preloader.loaded = event.progress / 100
            }, Main.prototype.onLoadingCompleted = function() {
                Common.assets.signals.progress.removeAll(), Common.assets.signals.complete.removeAll(), this._preloader.loaded = 1, Common.config = Common.assets.getJSON("config"), Common.copy = Common.assets.getJSON("copy"), delay(function() {
                    this.startGame()
                }, .4, this)
            }, Main.prototype.onCanvasResize = function(correct) {
                correct && (Common.renderer.resize(p3.View.width, p3.View.height), Common.scene && Common.scene.resize())
            }
        }, {
            "./Application": 2,
            "./AudioManager": 3,
            "./CNPreloaderScene": 7,
            "./Common": 10,
            "./Input": 21
        }],
        26: [function(require, module, exports) {
            "use strict";

            function Player() {
                this.speed = 400, this.tilt = 820, this.fireRate = .26, this.fireOffset = new PIXI.Point(32, (-20)), this._chain = [], this._fireTime = 0, this._direction = 1, this._directionIndex = 0, this._directionArr = [1, 0, -1, 0], this._changeDirection = !1, this._invulnerable = !1, this._shield = !1, this._moving = !1, this._flapSFX = null, Actor.call(this);
                var holder = new PIXI.Container;
                holder.x = 2, holder.y = 60, this.addChild(holder), this.spine = new PIXI.spine.Spine(Common.assets.getSpineData("char_stinkfly")), this.spine.skeleton.setToSetupPose(), this.spine.skeleton.setSkin(null), this.spine.autoUpdate = !1, this.spine.scale.set(.5), holder.addChild(this.spine), this.spine.stateData.setMixByName("idle_001", "move_001", .2), this.spine.stateData.setMixByName("move_001", "idle_001", .2), this.spine.stateData.setMixByName("move_001", "move_001", .1), this.spine.stateData.setMixByName("idle_001", "carry_001", .1), this.spine.stateData.setMixByName("move_001", "carry_001", .1), this.spine.stateData.setMixByName("carry_001", "idle_001", .1), this.spine.stateData.setMixByName("carry_001", "move_001", .1), this.spine.stateData.setMixByName("carry_001", "carry_002", .1), this.spine.stateData.setMixByName("carry_002", "carry_001", .1), this.spine.stateData.setMixByName("carry_002", "idle_001", .1), this.spine.stateData.setMixByName("carry_002", "move_001", .1), this.signals.fire = new signals.Signal, this.signals.dead = new signals.Signal
            }
            var Actor = require("./Actor"),
                AudioParams = require("./AudioParams"),
                CollisionGroups = (require("./Camper"), require("./CollisionGroups")),
                Common = require("./Common"),
                Projectile = require("./Projectile"),
                ProjectileTypes = require("./ProjectileTypes");
            module.exports = Player, Player.prototype = Object.create(Actor.prototype), Player.prototype.constructor = Player, Player.prototype.init = function() {
                if (Actor.prototype.init.call(this), this.spine.state.setAnimationByName(0, "idle_001", !0), !this._flapSFX) {
                    var params = new AudioParams;
                    params.volume = .2, params.loop = !0, this._flapSFX = Common.audio.playSound("sfx_stinkfly_flap_00", params)
                }
            }, Player.prototype.destroy = function() {
                this.signals.fire.dispose(this), this.signals.dead.dispose(this), this._flapSFX && (this._flapSFX.stop(), this._flapSFX = null), Actor.prototype.destroy.call(this)
            }, Player.prototype.createBody = function() {
                var body = new p2.Body({
                    mass: 1
                });
                body.type = p2.Body.DYNAMIC, body.allowSleep = !0, body.damping = .82, body.gravityScale = 0, body.fixedRotation = !0;
                var radius = 64,
                    shape = new p2.Circle({
                        radius: radius
                    });
                shape.material = this._material, shape.collisionGroup = CollisionGroups.PLAYER, shape.collisionMask = CollisionGroups.TERRAIN_FLOOR | CollisionGroups.TERRAIN_OTHER | CollisionGroups.ENEMY | CollisionGroups.PROJECTILE_BAD | CollisionGroups.GIESER, body.addShape(shape);
                var sensor = new p2.Circle({
                    radius: radius
                });
                return sensor.collisionGroup = CollisionGroups.PLAYER, sensor.collisionMask = CollisionGroups.CAMPER | CollisionGroups.POWERUP, sensor.sensor = !0, body.addShape(sensor), body
            }, Player.prototype.update = function() {
                Common.input.isKeyLeft && this._body.applyForce([-this.speed, 0]), Common.input.isKeyRight && this._body.applyForce([this.speed, 0]), Common.input.isKeyUp && this._body.applyForce([0, -this.speed]), Common.input.isKeyDown && this._body.applyForce([0, this.speed]), this._chain.length <= 0 && (!Common.input.isKeyLeft && !Common.input.isKeyRight || this._moving ? Common.input.isKeyLeft || Common.input.isKeyRight || !this._moving || (this._moving = !1, 0 != this.direction && this.spine.state.setAnimationByName(0, "idle_001", !0), this.spine.parent.y = 60) : (this._moving = !0, 0 != this.direction && this.spine.state.setAnimationByName(0, "move_001", !0), this.spine.parent.y = 60)), Actor.prototype.update.call(this);
                var velocity = this._body.velocity;
                this._body.angle = velocity[0] / this.tilt, Common.input.isKeyAltFire ? this._changeDirection || (this._changeDirection = !0, this.changeDirection()) : this._changeDirection = !1, Common.input.isKeyFire && this._fireTime <= 0 && (this._fireTime = this.fireRate, this.fire()), this._fireTime = Math.max(0, this._fireTime - p3.Timestep.deltaTime), this._shield && (this._shield.x = this.x, this._shield.y = this.y + 10), this.spine.update(p3.Timestep.deltaTime)
            }, Player.prototype.grab = function(camper) {
                if (!(this._chain.length >= 3)) {
                    camper.chained = !0;
                    var constraint = new p2.RevoluteConstraint(this.chainHead.body, camper.body, {
                        localPivotA: [0, this.chainHead == this ? 12 : this.chainHead.body.shapes[0].radius],
                        localPivotB: [0, -camper.body.shapes[0].radius],
                        maxForce: 2e4
                    });
                    Common.world.addConstraint(constraint), camper.body.constraint = constraint, this._chain.push(camper), this.adjustChainLimits(), this._chain.length > 0 && (0 != this.direction ? this.spine.state.setAnimationByName(0, "carry_001", !0) : this.spine.state.setAnimationByName(0, "carry_003", !0), this.spine.parent.y = 20), Common.audio.playSound("sfx_stinkfly_holdperson_01"), Math.random() < .5 && Common.audio.playSound("vo_ben_lift_00")
                }
            }, Player.prototype.breakChain = function(count) {
                function reset(camper) {
                    delay(function() {
                        camper.chained = !1
                    }, 1, this)
                }
                if (count = "number" == typeof count ? count : this._chain.length, this._chain.length) {
                    for (var camper, i = 0; i++ < count;) camper = this._chain.pop(), reset.call(this, camper), Common.world.removeConstraint(camper.body.constraint), camper.body.constraint = null;
                    this.adjustChainLimits(), this._chain.length > 0 ? (0 != this.direction ? this.spine.state.setAnimationByName(0, "carry_001", !0) : this.spine.state.setAnimationByName(0, "carry_003", !0), this.spine.parent.y = 20) : (0 != this.direction ? this.spine.state.setAnimationByName(0, "idle_001", !0) : this.spine.state.setAnimationByName(0, "idle_002", !0), this.spine.parent.y = 60), Common.audio.playSound("vo_ben_whoa_00")
                }
            }, Player.prototype.adjustChainLimits = function() {
                for (var camper, scale = .4 * (1 - (this._chain.length - 1) / 3), i = 0; i < this._chain.length; ++i) camper = this._chain[i], camper.body.constraint.setLimits(-Math.PI * scale, Math.PI * scale)
            }, Player.prototype.fire = function() {
                var sequence = new p3.MovieClipSequence;
                sequence.addTextures([Common.assets.getTexture("projectile_slime")]);
                var speed = 16e3,
                    angle = this.rotation;
                this._direction == -1 ? angle += Math.PI : 0 == this._direction && (angle = .5 * Math.PI);
                var v = [0, 0];
                v[0] = Math.cos(angle) * speed, v[1] = Math.sin(angle) * speed;
                var goo = new Projectile(this, sequence, ProjectileTypes.GOOD);
                goo.x = this.body.position[0] + this.fireOffset.x, goo.y = this.body.position[1] + this.fireOffset.y, goo.rotation = Math.atan2(v[1], v[0]), goo.body.applyForce(v), this.signals.fire.dispatch(this, goo), Common.audio.playSound("sfx_stinkfly_shoot_02")
            }, Player.prototype.makeInvulnerable = function(duration) {
                this._invulnerable || (this._invulnerable = !0, this._shield = new PIXI.Sprite(Common.assets.getTexture("shield_btm")), this._shield.anchor = new PIXI.Point(.5, .5), this.parent.addChild(this._shield), delay(function() {
                    TweenMax.to(this._shield, .4, {
                        alpha: 0,
                        ease: Power1.easeInOut,
                        onComplete: function() {
                            this._invulnerable = !1, this._shield.parent.removeChild(this._shield)
                        },
                        onCompleteScope: this
                    })
                }, duration, this))
            }, Player.prototype.takeDamage = function(value, source, animate) {
                if (!this._invulnerable) {
                    var sounds = ["vo_ben_hurt_00", "vo_ben_oohoof_00", "vo_ben_release_00"];
                    return 0 == this._chain.length && Common.audio.playSound(sounds), Actor.prototype.takeDamage.call(this, value, source, animate)
                }
                if (source) {
                    var to = new p3.Vector2(source.x - this.x, source.y - this.y),
                        angle = Math.atan2(to.y, to.x),
                        arc = new PIXI.Sprite(Common.assets.getTexture("shield_top"));
                    arc.anchor = new PIXI.Point(.5, .5), arc.rotation = angle, this._shield.addChild(arc), TweenMax.to(arc, .2, {
                        delay: .2,
                        alpha: 0,
                        ease: Power1.easeOut,
                        onComplete: function() {
                            arc.parent.removeChild(arc)
                        },
                        onCompleteScope: this
                    })
                }
            }, Player.prototype.changeDirection = function() {
                return this._direction = this._directionArr[++this._directionIndex % this._directionArr.length], 1 == this._direction ? (this.spine.parent.scale.x = 1, this.fireOffset = new PIXI.Point(24, (-20)), this._moving = !1, 0 == this._chain.length ? this.spine.state.setAnimationByName(0, "idle_001", !0) : this.spine.state.setAnimationByName(0, "carry_001", !0)) : this._direction == -1 ? (this.spine.parent.scale.x = -1, this.fireOffset = new PIXI.Point((-24), (-20)), this._moving = !1, 0 == this._chain.length ? this.spine.state.setAnimationByName(0, "idle_001", !0) : this.spine.state.setAnimationByName(0, "carry_001", !0)) : 0 == this._direction && (this.fireOffset = new PIXI.Point(0, (-8)), 0 == this._chain.length ? this.spine.state.setAnimationByName(0, "idle_002", !0) : this.spine.state.setAnimationByName(0, "carry_003", !0)), Common.audio.playSound("sfx_stinkfly_changedirection_00"), this._direction
            }, Player.prototype.isGrabbed = function(actor) {
                return this._chain.indexOf(actor) != -1
            }, Player.prototype.debugDraw = function(graphics) {
                var shape = this.body.shapes[0];
                graphics.lineStyle(2, 16776960, .4), graphics.beginFill(16776960, .2), graphics.drawCircle(this.body.position[0] + shape.position[0], this.body.position[1] + shape.position[1], shape.radius), graphics.endFill()
            }, Object.defineProperty(Player.prototype, "chainHead", {
                get: function() {
                    return this._chain.length > 0 ? this._chain[this._chain.length - 1] : this
                }
            }), Object.defineProperty(Player.prototype, "direction", {
                get: function() {
                    return this._direction
                }
            }), Object.defineProperty(Player.prototype, "invulnerable", {
                get: function() {
                    return this._invulnerable
                }
            })
        }, {
            "./Actor": 1,
            "./AudioParams": 4,
            "./Camper": 8,
            "./CollisionGroups": 9,
            "./Common": 10,
            "./Projectile": 30,
            "./ProjectileTypes": 31
        }],
        27: [function(require, module, exports) {
            "use strict";

            function Powerup(type) {
                this._type = type, this._animateTweenY = 0, this._emitter = null;
                var sequence = new p3.MovieClipSequence;
                switch (type) {
                    case PowerupTypes.HEALTH:
                        sequence.addTextures([Common.assets.getTexture("pick_up_health_small")]);
                        break;
                    case PowerupTypes.INVULNERABILITY:
                        sequence.addTextures([Common.assets.getTexture("pick_up_shield")])
                }
                Actor.call(this), this.view = new p3.MovieClip(sequence), this.view.anchor = new PIXI.Point(.5, .5), this.addChild(this.view)
            }
            var Actor = require("./Actor"),
                CollisionGroups = require("./CollisionGroups"),
                Common = require("./Common"),
                PowerupTypes = require("./PowerupTypes");
            module.exports = Powerup, Powerup.prototype = Object.create(Actor.prototype), Powerup.prototype.constructor = Powerup, Powerup.prototype.init = function() {
                Actor.prototype.init.call(this), this.scale = new PIXI.Point, TweenMax.to(this.scale, .6, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2]
                }), this._animateTweenY = this.body.position[1], TweenMax.to(this, 1.4, {
                    _animateTweenY: .5 * p3.View.height,
                    ease: Power1.easeOut,
                    easeParams: [1],
                    onUpdate: function() {
                        this.body.position[1] = this._animateTweenY
                    },
                    onUpdateScope: this,
                    onComplete: function() {
                        TweenMax.to(this, 2, {
                            _animateTweenY: .5 * p3.View.height + 20,
                            ease: Power1.easeInOut,
                            onUpdate: function() {
                                this.body.position[1] = this._animateTweenY
                            },
                            onUpdateScope: this,
                            yoyo: !0,
                            repeat: -1
                        })
                    },
                    onCompleteScope: this
                });
                var config = Common.assets.getJSON("particle_transform_pickup_attract_add_00");
                this._emitter = new cloudkid.Emitter(this.parent, [Common.assets.getTexture("particle_001")], config), this._emitter.emit = !0, this._emitter.updateOwnerPos(this.x, this.y)
            }, Powerup.prototype.destroy = function() {
                TweenMax.killTweensOf(this), this._emitter && (this._emitter.destroy(), this._emitter = null), Actor.prototype.destroy.call(this)
            }, Powerup.prototype.update = function() {
                Actor.prototype.update.call(this), this._emitter && (this._emitter.updateOwnerPos(this.x, this.y), this._emitter.update(p3.Timestep.deltaTime))
            }, Powerup.prototype.createBody = function() {
                var body = new p2.Body({
                    mass: .62
                });
                body.type = p2.Body.KINEMATIC, body.allowSleep = !1, body.fixedRotation = !0;
                var shape = new p2.Circle({
                    radius: 40
                });
                return shape.collisionGroup = CollisionGroups.POWERUP, shape.collisionMask = CollisionGroups.PLAYER, shape.sensor = !0, body.addShape(shape), body
            }, Powerup.prototype.debugDraw = function(graphics) {
                var shape = this.body.shapes[0];
                graphics.lineStyle(2, 65280, .4), graphics.beginFill(65280, .2), graphics.drawCircle(this.body.position[0] + shape.position[0], this.body.position[1] + shape.position[1], shape.radius), graphics.endFill()
            }, Object.defineProperty(Powerup.prototype, "type", {
                get: function() {
                    return this._type
                }
            })
        }, {
            "./Actor": 1,
            "./CollisionGroups": 9,
            "./Common": 10,
            "./PowerupTypes": 28
        }],
        28: [function(require, module, exports) {
            "use strict";

            function PowerupTypes() {}
            module.exports = PowerupTypes, PowerupTypes.HEALTH = "health", PowerupTypes.INVULNERABILITY = "invulnerability"
        }, {}],
        29: [function(require, module, exports) {
            "use strict";

            function PreloaderScene() {
                this.loaded = 0, this._spinnerCenter = null, this._spinnerBlack = null, this._spinnerWhite = null, this._radials = [], this._emitterHolder = null, this._emitter = null, p3.Scene.call(this)
            }
            var Common = require("./Common"),
                DistortionEffect = require("./DistortionEffect");
            module.exports = PreloaderScene, PreloaderScene.prototype = Object.create(p3.Scene.prototype), PreloaderScene.prototype.constructor = PreloaderScene, PreloaderScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("preloader_bg"));
                this.addChild(bg);
                for (var radial, textures = [Common.assets.getTexture("preloader_radial_001"), Common.assets.getTexture("preloader_radial_002"), Common.assets.getTexture("preloader_radial_003"), Common.assets.getTexture("preloader_radial_004"), Common.assets.getTexture("preloader_radial_005"), Common.assets.getTexture("preloader_radial_006"), Common.assets.getTexture("preloader_radial_007"), Common.assets.getTexture("preloader_radial_008")], offset = Math.random() * (2 * Math.PI), angle = 2 * Math.PI / textures.length, i = 0; i < textures.length; ++i) radial = new PIXI.Sprite(textures[i]), radial.rotation = offset + i * angle, radial.x = .5 * Common.STAGE_WIDTH + 140 * Math.sin(radial.rotation), radial.y = .5 * Common.STAGE_HEIGHT + 140 * -Math.cos(radial.rotation), radial.anchor = new PIXI.Point(.5, 1), radial.visible = !1, this.addChild(radial), this._radials.push(radial);
                this._emitterHolder = new PIXI.Container, this._emitterHolder.x = .5 * Common.STAGE_WIDTH, this._emitterHolder.y = .5 * Common.STAGE_HEIGHT, this.addChild(this._emitterHolder);
                var config = Common.assets.getJSON("preloader_radial_spray");
                this._emitter = new cloudkid.Emitter(this._emitterHolder, [Common.assets.getTexture("particle_001"), Common.assets.getTexture("particle_002"), Common.assets.getTexture("particle_003"), Common.assets.getTexture("particle_004"), Common.assets.getTexture("particle_005"), Common.assets.getTexture("particle_006"), Common.assets.getTexture("particle_007")], config), this._emitter.emit = !1;
                var holder = new PIXI.Container;
                holder.x = .5 * Common.STAGE_WIDTH, holder.y = .5 * Common.STAGE_HEIGHT, this.addChild(holder), DistortionEffect.shake(holder), this._spinnerBlack = new PIXI.Sprite(Common.assets.getTexture("preloader_ring_black")), this._spinnerBlack.anchor = new PIXI.Point(.5, .5), this._spinnerBlack.visible = !1, holder.addChild(this._spinnerBlack), this._spinnerCenter = new PIXI.Sprite(Common.assets.getTexture("preloader_ring_centre")), this._spinnerCenter.anchor = new PIXI.Point(.5, .5), this._spinnerCenter.visible = !1, holder.addChild(this._spinnerCenter), this._spinnerWhite = new PIXI.Sprite(Common.assets.getTexture("preloader_ring_white")), this._spinnerWhite.anchor = new PIXI.Point(.5, .5), this._spinnerWhite.visible = !1, holder.addChild(this._spinnerWhite)
            }, PreloaderScene.prototype.dispose = function() {}, PreloaderScene.prototype.appear = function() {
                this.animateIn()
            }, PreloaderScene.prototype.show = function() {}, PreloaderScene.prototype.animateIn = function(callback, scope) {
                this._emitter.emit = !0, this._spinnerBlack.scale = new PIXI.Point, this._spinnerBlack.visible = !0, TweenMax.to(this._spinnerBlack.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Power2.easeOut,
                    easeParams: [2]
                }), this._spinnerCenter.scale = new PIXI.Point, this._spinnerCenter.visible = !0, TweenMax.to(this._spinnerCenter.scale, .4, {
                    delay: .06,
                    x: 1,
                    y: 1,
                    ease: Power2.easeOut,
                    easeParams: [2]
                }), this._spinnerWhite.scale = new PIXI.Point, this._spinnerWhite.visible = !0, TweenMax.to(this._spinnerWhite.scale, .46, {
                    delay: .08,
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [4]
                }), TweenMax.to(this._spinnerCenter.scale, 1.4, {
                    delay: .6,
                    x: .94,
                    y: .94,
                    ease: Back.easeOut,
                    yoyo: !0,
                    repeat: -1
                }), TweenMax.to(this._spinnerBlack, 8, {
                    delay: .2,
                    rotation: 8 * Math.PI,
                    ease: Power1.easeInOut,
                    yoyo: !0,
                    repeat: -1
                }), TweenMax.to(this._spinnerWhite, 6, {
                    delay: .24,
                    rotation: 8 * -Math.PI,
                    ease: Power1.easeInOut,
                    yoyo: !0,
                    repeat: -1
                });
                for (var radial, i = 0; i < this._radials.length; ++i) radial = this._radials[i], radial.visible = !0, radial.scale.y = 0, TweenMax.to(radial.scale, .8, {
                    delay: .14 + .2 * Math.random(),
                    y: 1,
                    ease: Back.easeOut,
                    easeParams: [2 * Math.random()],
                    onComplete: function(radial) {
                        TweenMax.to(radial.scale, 1.6 + .4 * Math.random(), {
                            delay: .94 * Math.random(),
                            y: .9,
                            ease: Power1.easeInOut,
                            yoyo: !0,
                            repeat: -1
                        })
                    },
                    onCompleteParams: [radial],
                    onCompleteScope: this
                })
            }, PreloaderScene.prototype.animateOut = function(callback, scope) {}, PreloaderScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH)
            }, PreloaderScene.prototype.update = function() {
                this._emitter.update(p3.Timestep.deltaTime)
            }
        }, {
            "./Common": 10,
            "./DistortionEffect": 12
        }],
        30: [function(require, module, exports) {
            "use strict";

            function Projectile(owner, sequence, type) {
                this._owner = owner, this._type = type | ProjectileTypes.GOOD, Actor.call(this), this.view = new p3.MovieClip(sequence), this.view.anchor = new PIXI.Point(.5, .5), this.addChild(this.view)
            }
            var Actor = require("./Actor"),
                CollisionGroups = require("./CollisionGroups"),
                Common = require("./Common"),
                ProjectileTypes = require("./ProjectileTypes");
            module.exports = Projectile, Projectile.prototype = Object.create(Actor.prototype), Projectile.prototype.constructor = Projectile, Projectile.prototype.createBody = function() {
                var body = new p2.Body({
                    mass: 1
                });
                body.type = p2.Body.DYNAMIC, body.allowSleep = !0, body.damping = 0, body.gravityScale = .4, body.fixedRotation = !0;
                var radius = 10,
                    shape = new p2.Circle({
                        radius: radius
                    });
                switch (this._type) {
                    case ProjectileTypes.GOOD:
                        shape.collisionGroup = CollisionGroups.PROJECTILE_GOOD, shape.collisionMask = CollisionGroups.ENEMY;
                        break;
                    case ProjectileTypes.BAD:
                        shape.collisionGroup = CollisionGroups.PROJECTILE_BAD, shape.collisionMask = CollisionGroups.PLAYER | CollisionGroups.CAMPER_CHAIN
                }
                return body.addShape(shape), body
            }, Projectile.prototype.collideWith = function(target, damage) {
                target.takeDamage(damage), this.destroyNextFrame = !0;
                var config = Common.assets.getJSON("particle_emitter_player_hit_00"),
                    emitter = new cloudkid.Emitter(this.parent, [Common.assets.getTexture("particle_player_hit_001")], config);
                emitter.emit = !0, emitter.updateOwnerPos(this.x, this.y), Common.animator.add(emitter)
            }, Object.defineProperty(Projectile.prototype, "owner", {
                get: function() {
                    return this._owner
                }
            })
        }, {
            "./Actor": 1,
            "./CollisionGroups": 9,
            "./Common": 10,
            "./ProjectileTypes": 31
        }],
        31: [function(require, module, exports) {
            "use strict";

            function ProjectileTypes() {}
            module.exports = ProjectileTypes, ProjectileTypes.GOOD = 0, ProjectileTypes.BAD = 1
        }, {}],
        32: [function(require, module, exports) {
            "use strict";

            function ResultScene(score, victory) {
                this._score = score || 0, this._victory = victory, this._titleText = null, this._scoreText = null, this._highscoreText = null, this._alien = null, this._homeButton = null, this._soundButton = null, this._replayButton = null, this._nextButton = null, p3.Scene.call(this)
            }
            var AudioParams = require("./AudioParams"),
                BenButton = require("./BenButton"),
                BenMuteButton = require("./BenMuteButton"),
                Common = require("./Common"),
                PreloaderScene = require("./PreloaderScene");
            module.exports = ResultScene, ResultScene.prototype = Object.create(p3.Scene.prototype), ResultScene.prototype.constructor = ResultScene, ResultScene.prototype.preloader = function() {
                return new PreloaderScene
            }, ResultScene.prototype.load = function() {
                return [{
                    name: "end_game_bg",
                    url: "images/bg_end_game.jpg"
                }]
            }, ResultScene.prototype.unload = function() {
                Common.assets
            }, ResultScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("end_game_bg"));
                this.addChild(bg);
                var key = this._victory ? "greatwork" : "gameover";
                "ar" != Common.language && "ru" != Common.language ? (this._titleText = new PIXI.extras.BitmapText(Common.copy[key][Common.language], {
                    font: "100px Ahkio Green",
                    align: "center"
                }), this._titleText.x = .5 * (-this._titleText.textWidth + Common.STAGE_WIDTH) + 128, this._titleText.y = -this._titleText.textHeight + 308, this.addChild(this._titleText)) : (this._titleText = new PIXI.Text(Common.copy[key][Common.language], {
                    font: "100px Arial",
                    fill: "#69FF00",
                    stroke: "#044300",
                    strokeThickness: 10,
                    align: "center"
                }), this._titleText.x = .5 * (-this._titleText.width + Common.STAGE_WIDTH) + 128, this._titleText.y = -this._titleText.height + 308, this.addChild(this._titleText)), this._scoreText = new PIXI.extras.BitmapText(this._score.toString(), {
                    font: "64px Ahkio Orange",
                    align: "center"
                }), this._scoreText.x = .5 * (-this._scoreText.textWidth + Common.STAGE_WIDTH) + 128, this._scoreText.y = -this._scoreText.textHeight + 382, this.addChild(this._scoreText), "ar" != Common.language && "ru" != Common.language ? (this._highscoreText = new PIXI.extras.BitmapText(Common.copy.highscore[Common.language].replace("[SCORE]", Common.getHighscore()), {
                    font: "60px Ahkio White",
                    align: "center"
                }), this._highscoreText.x = .5 * (-this._highscoreText.textWidth + Common.STAGE_WIDTH) + 128, this._highscoreText.y = 390, this.addChild(this._highscoreText)) : (this._highscoreText = new PIXI.Text(Common.copy.highscore[Common.language].replace("[SCORE]", Common.getHighscore()), {
                    font: "60px Arial",
                    fill: "#FFFFFF",
                    stroke: "#044300",
                    strokeThickness: 10,
                    align: "center"
                }), this._highscoreText.x = .5 * (-this._highscoreText.width + Common.STAGE_WIDTH) + 128, this._highscoreText.y = 386, this.addChild(this._highscoreText)), this._alien = new PIXI.Sprite(Common.assets.getTexture("stinkfly_endgame")), this._alien.x = .5 * Common.STAGE_WIDTH - 400, this._alien.y = .5 * Common.STAGE_HEIGHT + 14, this._alien.anchor = new PIXI.Point(.5, .5), this.addChild(this._alien);
                var states = new p3.ButtonStates;
                states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_home_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_home_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._homeButton = new BenButton(states), this._homeButton.y = 80, this._homeButton.animate = !0, this._homeButton.overSoundName = "sfx_btn_rollover_00", this._homeButton.clickSoundName = "sfx_btn_back", this._homeButton.signals.click.add(this.onHomeButtonClick, this), this.addChild(this._homeButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_audio_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_audio_over"), states.iconAlt = Common.assets.getTexture("btn_tertuary_icon_mute_off"), states.iconOverAlt = Common.assets.getTexture("btn_tertuary_icon_mute_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._soundButton = new BenMuteButton(states), this._soundButton.y = 80, this._soundButton.animate = !0, this._soundButton.overSoundName = "sfx_btn_rollover_00", this._soundButton.clickSoundName = "sfx_btn_press_00", this.addChild(this._soundButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_primary_medium_off"), states.over = Common.assets.getTexture("btn_primary_medium_over"), states.icon = Common.assets.getTexture("btn_primary_medium_icon_replay_off"), states.iconOver = Common.assets.getTexture("btn_primary_medium_icon_replay_over"), states.innerRing = Common.assets.getTexture("btn_primary_medium_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_primary_medium_off_ring_001"), this._replayButton = new BenButton(states), this._replayButton.y = p3.View.height - 100, this._replayButton.animate = !0, this._replayButton.overSoundName = "sfx_btn_rollover_00", this._replayButton.clickSoundName = "sfx_btn_play_00", this._replayButton.signals.click.add(this.onReplayButtonClick, this), this.addChild(this._replayButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_primary_medium_off"), states.over = Common.assets.getTexture("btn_primary_medium_over"), states.icon = Common.assets.getTexture("btn_primary_medium_icon_next_off"), states.iconOver = Common.assets.getTexture("btn_primary_medium_icon_next_over"), states.innerRing = Common.assets.getTexture("btn_primary_medium_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_primary_medium_off_ring_001"), this._nextButton = new BenButton(states), this._nextButton.y = p3.View.height - 100, this._nextButton.animate = !0, this._nextButton.visible = this._victory, this._nextButton.overSoundName = "sfx_btn_rollover_00", this._nextButton.clickSoundName = "sfx_btn_play_00", this._nextButton.signals.click.add(this.onNextButtonClick, this), this.addChild(this._nextButton), p3.Scene.prototype.init.call(this)
            }, ResultScene.prototype.destroy = function() {
                this._homeButton.destroy(), this._soundButton.destroy(), this._replayButton.destroy(), this._nextButton.destroy(), p3.Scene.prototype.destroy.call(this)
            }, ResultScene.prototype.appear = function() {
                p3.Scene.prototype.appear.call(this);
                var params = new AudioParams;
                params.fadeIn = 1, Common.audio.playMusic("music_main_quiet_00", params);
                var sounds = ["vo_ben_win_haaa_00", "vo_ben_woohoo_00"];
                Common.audio.playSound(sounds)
            }, ResultScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._homeButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 80, this._soundButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 80, this._replayButton.x = .5 * (Common.STAGE_WIDTH - p3.View.width) + 100, this._nextButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 100
            }, ResultScene.prototype.update = function() {}, ResultScene.prototype.onHomeButtonClick = function(button) {
                this.signals.home.dispatch(this)
            }, ResultScene.prototype.onReplayButtonClick = function() {
                this.signals.previous.dispatch(this)
            }, ResultScene.prototype.onNextButtonClick = function(button) {
                this.signals.next.dispatch(this)
            }
        }, {
            "./AudioParams": 4,
            "./BenButton": 5,
            "./BenMuteButton": 6,
            "./Common": 10,
            "./PreloaderScene": 29
        }],
        33: [function(require, module, exports) {
            "use strict";

            function SafeZone() {
                var sequence = new p3.MovieClipSequence;
                sequence.addTextures([Common.assets.getTexture("drop_off")]), Actor.call(this), this.view = new p3.MovieClip(sequence), this.view.anchor = new PIXI.Point(.5, .5), this.addChild(this.view)
            }
            var Actor = require("./Actor"),
                CollisionGroups = require("./CollisionGroups"),
                Common = require("./Common");
            module.exports = SafeZone, SafeZone.prototype = Object.create(Actor.prototype), SafeZone.prototype.constructor = SafeZone, SafeZone.prototype.init = function() {
                Actor.prototype.init.call(this), TweenMax.to(this, 1, {
                    alpha: .44,
                    ease: Power1.easeInOut,
                    yoyo: !0,
                    repeat: -1
                })
            }, SafeZone.prototype.destroy = function() {
                Actor.prototype.destroy.call(this)
            }, SafeZone.prototype.createBody = function() {
                var body = new p2.Body({
                    mass: 1
                });
                body.type = p2.Body.STATIC, body.allowSleep = !0, body.collisionResponse = !1;
                var box = new p2.Box({
                    width: 160,
                    height: 20
                });
                return box.collisionGroup = CollisionGroups.SAFE_ZONE, box.collisionMask = CollisionGroups.CAMPER_CHAIN, box.sensor = !0, body.addShape(box, [0, 126]), body
            }, SafeZone.prototype.debugDraw = function(graphics) {
                var box = this.body.shapes[0];
                graphics.lineStyle(2, 255), graphics.beginFill(255, .4), graphics.drawRect(this.body.position[0] + (box.position[0] - .5 * box.width), this.body.position[1] + (box.position[1] - .5 * box.height), box.width, box.height), graphics.endFill()
            }
        }, {
            "./Actor": 1,
            "./CollisionGroups": 9,
            "./Common": 10
        }],
        34: [function(require, module, exports) {
            "use strict";

            function SplashScene() {
                p3.Scene.call(this), this._logo = null, this._playButton = null, this._soundButton = null
            }
            var AudioParams = require("./AudioParams"),
                BenMuteButton = (require("./BenButton"), require("./BenMuteButton")),
                Common = require("./Common");
            module.exports = SplashScene, SplashScene.prototype = Object.create(p3.Scene.prototype), SplashScene.prototype.constructor = SplashScene, SplashScene.prototype.init = function() {
                var bg = new PIXI.Sprite(Common.assets.getTexture("bg_splash"));
                this.addChild(bg), this._logo = new p3.AdditiveSprite(Common.assets.getTexture("title")), this._logo.x = .5 * Common.STAGE_WIDTH + 18, this._logo.y = 446, this._logo.rotation = -.154, this._logo.anchor = new PIXI.Point(.5, .5), this._logo.visible = !1, this.addChild(this._logo);
                var states = new p3.ButtonStates;
                states.normal = Common.assets.getTexture("btn_play_off"), states.over = Common.assets.getTexture("btn_play_over"), states.icon = Common.assets.getTexture("btn_play_icon_off"), states.iconOver = Common.assets.getTexture("btn_play_icon_over"), this._playButton = new p3.Button(states), this._playButton.x = .5 * Common.STAGE_WIDTH, this._playButton.y = 620, this._playButton.animate = !0, this._playButton.overSoundName = "sfx_btn_rollover_00", this._playButton.clickSoundName = "sfx_btn_play_00", this._playButton.signals.click.add(this.onPlayButtonClick, this), this.addChild(this._playButton), states = new p3.ButtonStates, states.normal = Common.assets.getTexture("btn_tertuary_off"), states.over = Common.assets.getTexture("btn_tertuary_over"), states.icon = Common.assets.getTexture("btn_tertuary_icon_audio_off"), states.iconOver = Common.assets.getTexture("btn_tertuary_icon_audio_over"), states.iconAlt = Common.assets.getTexture("btn_tertuary_icon_mute_off"), states.iconOverAlt = Common.assets.getTexture("btn_tertuary_icon_mute_over"), states.innerRing = Common.assets.getTexture("btn_tertuary_off_ring_001"), states.outerRing = Common.assets.getTexture("btn_tertuary_off_ring_002"), this._soundButton = new BenMuteButton(states), this._soundButton.y = 80, this._soundButton.animate = !0, this._soundButton.overSoundName = "sfx_btn_rollover_00", this._soundButton.clickSoundName = "sfx_btn_press_00", this.addChild(this._soundButton), p3.Scene.prototype.init.call(this)
            }, SplashScene.prototype.destroy = function() {
                this._playButton.destroy(), this._soundButton.destroy(), p3.Scene.prototype.destroy.call(this)
            }, SplashScene.prototype.resize = function() {
                this.x = .5 * (p3.View.width - Common.STAGE_WIDTH), this._soundButton.x = .5 * (Common.STAGE_WIDTH + p3.View.width) - 80
            }, SplashScene.prototype.appear = function() {
                p3.Scene.prototype.appear.call(this);
                var params = new AudioParams;
                params.fadeIn = 1, Common.audio.playMusic("music_main_fullloop_quiet_00", params)
            }, SplashScene.prototype.animateIn = function(callback, scope) {
                this._logo.scale = new PIXI.Point, this._logo.visible = !0, TweenMax.to(this._logo.scale, .4, {
                    x: 1,
                    y: 1,
                    ease: Back.easeOut,
                    params: [2]
                }), this._logo.blendStrength = .4, TweenMax.to(this._logo, .22, {
                    delay: .32,
                    blendStrength: 0,
                    ease: Power2.easeOut
                })
            }, SplashScene.prototype.animateOut = function(callback, scope) {}, SplashScene.prototype.update = function() {}, SplashScene.prototype.onPlayButtonClick = function(button) {
                this.signals.next.dispatch(this)
            }
        }, {
            "./AudioParams": 4,
            "./BenButton": 5,
            "./BenMuteButton": 6,
            "./Common": 10
        }],
        35: [function(require, module, exports) {
            "use strict";

            function Tent() {
                var sequence = new p3.MovieClipSequence;
                sequence.addTextures([Common.assets.getTexture("target_tent")]), Actor.call(this), this.view = new p3.MovieClip(sequence), this.view.anchor = new PIXI.Point(.5, .5), this.addChild(this.view)
            }
            var Actor = require("./Actor"),
                Common = require("./Common");
            module.exports = Tent, Tent.prototype = Object.create(Actor.prototype), Tent.prototype.constructor = Tent, Tent.prototype.createBody = function() {
                return new p2.Body
            }, Tent.prototype.update = function() {
                Actor.prototype.update.call(this)
            }
        }, {
            "./Actor": 1,
            "./Common": 10
        }]
    }, {}, [25])(25)
});